# Stuck to You — Memoria de proyecto

Este documento guarda el estado técnico y las decisiones que necesitamos recordar entre sesiones. El alcance y los checks diarios siguen viviendo en `PLAN_MVP.md`.

## Estado actual

**Última actualización:** 2026-08-19  
**Lugar de Roblox Studio:** `Exposición pegajosa`  
**Modo verificado:** Edit y Play  
**Fase:** Sistema de mundos cerrado. Hay dos mundos (`World1` "The House" y `World2` "The Mansion"), cada uno con su lobby, sus tiendas, sus 10 salas, sus pasillos con pedestal y su FinishZone. Se viaja entre ellos por un portal en cada lobby. Antes: Rebirth y Sticky Wraps cerrados. El Rebirth tiene botón en el HUD, pantalla modal authored y ciclo repetible probado hasta `Rebirths 2`. Hay 8 Sticky Wraps que se compran y equipan pisando las placas del lobby (y también desde la pantalla del HUD); el Rebirth los borra. Antes: persistencia cloud, reconexión, respawn y fallos de carga aprobados; objetos per-player probados con un jugador (prueba con 2 jugadores sigue pendiente, manual).

### Implementado

- Estructura base en servicios y `Workspace.StuckToYou`.
- `ReplicatedStorage.Shared.GameConfig` como fuente única de balance.
- Greybox lineal de Toy Room.
- StartSpawn propio y eliminación del SpawnLocation predeterminado.
- 12 spawn markers etiquetados como `ItemSpawn`.
- Toy Chest etiquetado como `StickinessBlocker`, con requisito 50.
- Funciones de configuración verificadas para Level, Wrap y Rebirth multiplier.
- Collectibles runtime generados desde tags y attributes de spawn markers.
- Pickup autoritativo con validación de requisito, distancia, Humanoid y bloqueo contra doble premio.
- Stickiness, Level y Sticky Wrap replicados mediante atributos del jugador. Los tres son progreso del ciclo de Rebirth: sobreviven a cobrar en un pedestal, al ReplayPad y a morir, y **solo el Rebirth los reinicia**.
- HUD funcional y labels rojo/verde calculados localmente desde estado replicado.
- Respawn configurable de 2 segundos con cancelación y limpieza explícitas.
- Pila visual server-side con 30 slots deterministas y propiedades físicas seguras.
- `AttachmentService` desacoplado mediante evento interno de colección.
- Pool global acotado a 60 piezas libres en `ServerStorage`.
- Crecimiento visual posterior al límite, acotado a 5 pasos.
- Reset de personaje sincronizado: reinicia run y devuelve visuals al pool.
- Toy Chest funcional con validación server-side y estado independiente por jugador.
- Estado visual verde/rojo y animación local de absorción mediante `BlockerController`.
- Salida física greybox hacia `ExitPreview` y transición de HUD a Bedroom.
- Timer de zona replicado en `LastZoneSeconds`.
- `RoomService` data-driven con registro por tag, validación estructural y API de consulta por `ZoneId`.
- ~~`SpawnService` desacoplado con 12 instancias reutilizadas~~ — **retirado el 2026-08-03**, sustituido por el sistema per-player.
- Respawn rotativo: el slot consumido vuelve al final de la cola y una posición distinta ocupa su lugar.
- Bedroom greybox con 12 spawns, Bed requerida a 180 y transición a Kitchen.
- Kitchen greybox con 12 spawns, Refrigerator requerido a 500 y objetivo lógico `FinishZone`.
- Tres pools simultáneos: cada zona mantiene 12 instancias, 10 activas, 2 reservas y 4 elegibles al entrar.
- `BlockerController` con estado rojo/verde completo y tres pases de descubrimiento inicial acotados/cancelables.
- FinishZone físico con `FinishSpawn`, resumen ambiental y `ReplayPad`, deliberadamente fuera del contrato/tag de salas con collectibles.
- `FinishService` server-authoritative con premio idempotente por vuelta, resumen replicado, teletransporte y replay sin recargar el character.
- Una Win exacta al absorber Refrigerator; pile limpia al terminar y Wins conservadas durante replay o muerte.
- APIs públicas pequeñas de reset en `BlockerService` y `AttachmentService`, y API de premio en `ProgressionService`.
- HUD muestra Wins y estado de vuelta completada.
- Tutorial ambiental de una línea junto al StartSpawn y ruta visual continua por las tres zonas.
- Relojes separados de zona y vuelta: `LastZoneSeconds` ya no es acumulativo y Finish conserva `LastRunSeconds` total.
- Stress de 10 vueltas/10 replays en un mismo servidor sin duplicar Wins, agotar pools ni dejar estado residual.
- `DataService` versionado con `UpdateAsync`, session lock, reintentos, autosave, liberación al salir/cerrar y mock aislado a Studio.
- Wins y Rebirths conectados al perfil persistente; Rebirth fuerza guardado inmediato.
- Rebirth autoritativo y **repetible** (2026-08-06): pide solo el level cap, conserva Wins, reinicia la vuelta, sube el techo 5 niveles y suma `+0.5x` permanente.
- `StarterGui.StickyHUD` authored y editable en Explorer; `HUDController` únicamente enlaza y actualiza la plantilla.
- Botón de Rebirth en el HUD y pantalla modal authored (`RebirthScreen`) con antes/después, barra de progreso y motivo de bloqueo; el cliente solo solicita y el servidor decide.
- Persistencia cloud verificada entre dos servidores con `Wins 1 / Rebirths 1` usando un almacén aislado de validación.
- Fallos de DataStore reproducibles mediante inyección limitada al mock de Studio; reintento y fallo terminal verificados.

### Sistema de mundos (2026-08-13)

- `GameConfig.Worlds`: cada mundo declara su lobby, su sala inicial, su FinishZone y su último blocker. La cadena de salas la sigue definiendo `NextZoneId`; el mundo solo dice dónde empieza y dónde acaba.
- Cada entrada de `GameConfig.Zones` lleva `WorldId`. `GetWorldZones`, `GetWorldOfZone` y `ResolveWorld` derivan todo lo demás.
- Requisitos de desbloqueo como catálogo (`GameConfig.WorldRequirements`) y mapa por mundo. `EvaluateWorldRequirements` la usan servidor y cliente, así que la pantalla nunca puede prometer algo que el servidor rechace.
- `WorldRegistry` (mapa mundo → instancias) y `WorldService` (portal, remotes, viaje). Las reglas y la persistencia viven en `ProgressionService`.
- Perfil: `CurrentWorldId`, `UnlockedWorldIds` y `TotalWinsEarned`.
- Portal authored en cada lobby, tag `WorldPortal` y atributo `WorldId`; abre `StickyHUD.WorldScreen`, con filas clonadas de `_WorldRow`.
- Mundo 2 completo en el editor: lobby con sus 8 placas de wrap y 7 de descanso, 10 salas, 10 pasillos con pedestal y FinishZone, desplazados `+900` en X y retintados.
- Botón temporal de desbloqueo (`GameConfig.WorldTravel.DebugUnlockEnabled`), con aviso en consola al arrancar.

### Objetos per-player (2026-08-03)

- Objetos privados por jugador: el servidor guarda los datos y el cliente renderiza sus propias instancias. Cero collectibles replicados desde el servidor.
- `ItemPlacementService`: slots válidos por sala calculados una vez, cacheados, con raycast a suelo, test de solapes y exclusiones alrededor de StartSpawn, puerta y blocker. Generación repartida en frames.
- `ItemPlanner`: módulo puro que reparte `TotalObjects` entre tipos y entre requisitos por resto mayor, garantizando el mínimo de objetos elegibles al entrar.
- `RoomSettingsReader`: lee la configuración authored del Workspace con fallback explícito a `GameConfig`.
- `RoomItemService`: una sesión por (jugador, sala) con una sola tarea de respawn por sesión.
- `PickupService`: valida sesión, requisito, distancia contra la posición del servidor, personaje vivo y rate limit por token bucket. Conserva el contrato `ConnectCollected`.
- Cliente: `CollectibleRenderer` (pool local de clones authored) y `CollectibleController` (un solo loop throttled de proximidad, sin `Touched` por objeto).
- `ObjectLabelController`: la elegibilidad se muestra atenuando los colores propios del prop (`IneligibleTintFactor`) y haciéndolo semitransparente (`IneligibleTransparency`), no con Highlights. Roblox solo renderiza 31 Highlights por cliente y no hay forma de subirlo, así que cualquier estado por objeto basado en ellos se rompe en silencio al crecer la sala. Queda un único Highlight como marca de "este es el que vas a agarrar".
- Plantillas authored en `ReplicatedStorage/Assets/Collectibles`: 9 props greybox y `_RequirementBillboard`. La tarjeta se dimensiona en studs (`Size = {2.6, 0}, {1.27, 0}`), con `AlwaysOnTop = false` y `MaxDistance = 50`.
- Plantillas authored de gratificación en `ReplicatedStorage/Assets/Feedback`: `Audio/` (`Pickup`, `Denied`, `LevelUp`, `Absorb`, `Rebirth`, `RestTick`, `WinClaim`, `UIClick`, `StickyGain`, `Purchase`, `Equip`), `Particles/` (`PickupBurst`, `AbsorbBurst`) y `UI/_ScorePopup`. `FeedbackController` solo las clona y dispara; los pools y los tiempos viven en `GameConfig.Feedback`.
- Audio definitivo (agosto 2026): se sustituyeron los placeholders de ProSoundEffects por los assets propios con permisos concedidos. `Denied` y `RestTick` conservan su placeholder a propósito. `StickyGain` (ingreso de stickiness) suena **encima** de `Pickup` a `Volume 0.10`: son dos capas del mismo golpe, el objeto pegándose y lo que produce, y sólo `Pickup` sube de tono con el combo. `Purchase` y `Equip` son canales nuevos: antes comprar sonaba como absorber y equipar como subir de nivel, así que la tienda no tenía voz propia. `FeedbackController` escucha ahora también `CosmeticFeedback`, porque Trails y Auras se compraban y equipaban en silencio.
- Pasada de iluminación: `ColorGrade` (`ColorCorrectionEffect`, `Saturation 0.28`), `Bloom` con `Threshold 1.15`, `Atmosphere` con `Haze 0.7`, ambiente azulado. `Lighting.Technology` no se puede escribir desde el command bar (requiere capacidad `RobloxScript`); ponerla a `Future` es un paso manual pendiente.
- El Sticky Wrap equipado se lee por color: el `+N` de cada recogida usa el `Color` del wrap, el nombre en el HUD va del mismo color vía `RichText` y la tienda pinta una franja con él. Al equipar uno mejor sale su nombre como popup; bajar de wrap a propósito no se celebra. Ver `GameConfig.Feedback.TintPopupWithWrapColor`.
- Configuración editable a mano por sala en `Zones/<Zone>/RoomSettings` y volumen `PlacementArea` por sala.
- `AttachmentService` reescrito: la pila pega un clon de **la misma plantilla que el jugador acaba de recoger**, no un cubo genérico. El tamaño se normaliza contra `TargetMaxSizeStuds` para que props de distinto tamaño authored se lean parecidos, y el prop conserva su color propio.
- Las soldaduras se reconstruyen al cambiar de paso de crecimiento, para que escalar un modelo multiparte no rompa las constraints.
- Límite de la pila subido de 30 a **36** slots (un anillo más, por debajo de la cabeza para no tapar la cámara). Al llenarse, cada nuevo pickup expulsa el más viejo y ocupa su slot, así que el jugador siempre lleva lo último que recogió.
- Dos animaciones cortas movidas por un único `Heartbeat` compartido: el objeto recogido vuela desde donde estaba hasta el cuerpo, y el expulsado se encoge y se desvanece en `Workspace.StickyDiscards`, desacoplado de la vida del personaje para que un reset a mitad del fundido no destruya una instancia del pool.
- `ClientMain` aísla el arranque de cada controlador con `pcall`: un fallo sigue avisando en consola pero ya no impide que arranquen los demás.
- **Los blockers absorbidos también se pegan al jugador.** `AttachmentService` clona el modelo authored del blocker desde el Workspace, más grande que un collectible (`BlockerSizeMultiplier`), y lo protege del reciclaje FIFO (`ProtectBlockerAttachments`). Solo hay 3 blockers por vuelta, así que cuesta 3 slots de 36 y conserva la lectura de "llevo puesta la puerta que rompí".
- El clon de un blocker se sanea antes de entrar al mundo: se le quitan los tags, los atributos `BlockerId`/`NextZoneId` y los `BillboardGui`. Sin eso, `BlockerController` descubriría la copia que lleva el jugador como si fuera un blocker real, porque escanea `Workspace` buscando el atributo `BlockerId`.
- `BlockerService.ConnectAbsorbed` emite una tabla interna con `Instance` y `Position` además del payload que va al cliente; el remoto no lleva la referencia a la instancia porque el cliente no la necesita.
- **Bug corregido:** `BlockerController` capturaba la lista de partes de un blocker una sola vez, al descubrir el Model. Un Model y sus partes no tienen por qué llegar al cliente en el mismo frame, así que una lista incompleta dejaba partes sin ocultar al absorber, y los pases de reintento se salían porque el registro ya existía. Ahora la lista se auto-repara con `refreshParts` en cada actualización y con `DescendantAdded`. Regla general para este proyecto: **no cachear listas de descendientes replicados sin una vía de reparación.**

### Pedestales de Win (2026-08-03)

- Pasillo corto authored después de la puerta de cada sala, en `Workspace/StuckToYou/Corridors/<Zona>Exit`: dos paredes laterales, una franja de suelo y el pedestal.
- El pedestal paga 1 / 3 / 10 Wins según la sala que se acaba de limpiar, y devuelve al jugador al inicio con la vuelta reiniciada. Pasar de largo conserva la vuelta y deja optar al pedestal mayor de la sala siguiente.
- `WinPedestalService` es data-driven por el tag `WinPedestal` y los atributos `ZoneId` y `WinReward`. El premio authored gana sobre el valor por zona de `GameConfig`.
- Solo paga si el jugador limpió esa zona en la vuelta actual (`CompletedZone_<ZoneId>`), con lock por jugador y debounce contra pagos dobles.
- `FinishService.ReturnToStart` centraliza reinicio y teletransporte; lo comparten el ReplayPad, el Rebirth y los pedestales.
- Las `PlacementArea` de Bedroom y Kitchen se recortaron para que no aparezcan objetos dentro de los pasillos.

### Todavía no implementado

- Confirmación manual con un jugador nuevo de que Toy Room dura 45–60 segundos.
- Prueba con 2 jugadores en la misma sala para el sistema per-player (pasos en `MANUAL_TEST_CHECKLIST.md`).
- Analítica y revisión responsive del miércoles.
- Poner `Lighting.Technology` en `Future` a mano: la propiedad no se puede escribir desde el command bar.

## Decisiones vigentes

- El documento nuevo del prototipo es la fuente de verdad del diseño.
- Solo existe un stat de run: Stickiness.
- El MVP usa 3 zonas; Neighborhood queda provisionalmente para semana 2.
- Los Sticky Wraps se desbloquean y equipan automáticamente por nivel, salvo que el usuario cambie esta decisión.
- No hay vida, daño, peso, banking de Wins ni obstáculos adicionales en el MVP.
- Todo premio y progreso se valida en servidor.
- Los números de balance viven en `GameConfig`, no dentro de servicios o UI.
- Los objetos visuales pegados tendrán un máximo inicial de 30.
- Toda UI y todo modelo/prop reutilizable nuevo debe existir como plantilla authored visible y editable en Studio; el código solo lo referencia, controla o clona.
- **Las Wins vienen de los pedestales, no de terminar la vuelta** (2026-08-03). Cada sala limpia pone un pedestal en el pasillo siguiente: pisarlo cobra y reinicia, pasarlo de largo arriesga la vuelta por el pedestal mayor. Por eso `GameConfig.Wins.AwardOnRunCompletion` está en `false` (si no, absorber el Refrigerator pagaría además de su pedestal) y `GameConfig.Finish.TeleportOnCompletion` también en `false` (si no, el jugador aparecería al otro lado del último pedestal y no podría cobrarlo). Ambos son flags reversibles.
- La FinishZone conserva su papel: es adonde llega quien pasa de largo el pedestal de 10, y sigue teniendo el ReplayPad y el panel de Rebirth.
- **Los objetos recolectables son privados por jugador** (decisión de diseño, 2026-08-03). Varios jugadores en la misma sala no se bloquean la progresión. Sustituye la nota anterior del plan que decía que los objetos serían compartidos durante la semana 1.
- El render de objetos vive en el cliente porque Roblox no permite filtrar la replicación de `Workspace` por jugador. El servidor sigue siendo dueño de todo el progreso y valida cada pickup contra su propia posición guardada.
- `TotalObjects` significa objetos visibles a la vez, no un total agotable por visita.
- El tipo de objeto es variedad visual, no balance. `GainMultiplier` queda reservado en `GameConfig.CollectibleTypes` para cuando diseño quiera usarlo.
- La configuración de cada sala se edita a mano en el Workspace (`RoomSettings`, `PlacementArea`); `GameConfig` solo aporta defaults. Un valor authored inválido cae al default con `warn` explícito, nunca en silencio.
- **Un solo modo de colocación** (2026-08-05). Se retiraron `PlacementMode`, los modos `Markers`/`Hybrid` y los 36 marcadores `ItemSpawns`. Nunca se usaron: las tres salas siempre estuvieron en `Procedural`. Mantener dos rutas de colocación sin datos era complejidad que había que leer y explicar cada vez. Si diseño quiere colocar objetos a mano en el futuro, se reimplementa.
- **`0 slots` en una sala casi siempre significa que falta el suelo dentro de su propia `Geometry`** (2026-08-05). El raycast de `ItemPlacementService` usa un filtro `Include` limitado a la carpeta `Geometry` de esa zona. Si el suelo se borra, se renombra o se mueve a otra carpeta, no hay nada que golpear y la sala produce cero posiciones, con el aviso `ItemPlacement: <Zona> produced 0 slots`. El jugador sigue caminando porque debajo está el `Baseplate`, que no cuenta para la colocación. Antes de tocar `TotalObjects` o `MinSeparationStuds`, comprobar que `Zones/<Zona>/Geometry/Floor` existe.
- **El audio sale de ProSoundEffects, no de lo más popular del Creator Store** (2026-08-05). Buscando SFX, casi todos los resultados mejor posicionados son rips con copyright (Mario Kart, Undertale, Sonic, Earthbound). Usarlos es riesgo de moderación al publicar. `ProSoundEffects` es la biblioteca licenciada que Roblox distribuye gratis, viene descrita y con duración, y es la fuente por defecto de este proyecto.
- **El texto de un `BillboardGui` se mide una sola vez y se puede quedar en cero** (2026-08-05). Si Roblox dispone la etiqueta cuando el billboard todavía no tiene tamaño en pantalla, calcula `TextBounds = 0,0` y **no vuelve a medir**: la tarjeta pinta su fondo pero nunca sus dígitos. Es la causa real del "panel negro sin texto", y también de que el cartel del pedestal de Win saliera mudo al construirlo a mano. Reactivar `TextScaled` fuerza el reescalado; `ObjectLabelController.healLabel` lo hace por tick sobre las tarjetas que tengan tamaño pero medida cero.
- **`TextScaled` y `TextWrapped` van juntos: apagar el segundo apaga el primero en silencio** (2026-08-05). Poner `TextWrapped = false` en una etiqueta con `TextScaled = true` deja `TextScaled = false` sin avisar, y el texto cae al `TextSize` de la plantilla (8 px aquí), o sea ilegible. Al tocar una de las dos, comprobar siempre la otra.
- **Las tarjetas de requisito se dimensionan en studs, nunca en píxeles** (2026-08-05). El `Size` de un `BillboardGui` en Offset conserva su tamaño en píxeles a cualquier distancia: con 24 objetos por sala las tarjetas lejanas quedan igual de grandes que las cercanas, se apilan en pantalla y, como el fondo del `TextLabel` es opaco, una tapa el número de otra y deja un rectángulo negro sin cifra. Con `Size` en Scale (studs) la tarjeta se aleja junto con su objeto. Además `AlwaysOnTop = false`, para que al solaparse gane la más cercana en vez de un orden de dibujado arbitrario en el que una tarjeta lejana tapa a una cercana. Medido en el peor caso (cámara a ras de suelo mirando la sala entera): 15 parejas solapadas antes, 3 después, y ninguna deja una tarjeta sin número.
- **Un mundo es un lobby más su cadena de salas, y nada más** (2026-08-13). No hay "modo mundo 2": las mismas reglas, los mismos servicios y los mismos pads, con otra escala. Lo único que un mundo aporta es dónde se empieza, dónde se acaba y qué hace falta para entrar.
- **El progreso viaja con el jugador; el mundo no lo reinicia.** Viajar no toca Stickiness, Level ni Wrap: solo reposiciona la zona lógica, limpia los blockers de la vuelta y teletransporta. Sigue siendo cierto que **solo el Rebirth reinicia la Stickiness**, y renacer devuelve a la primera sala **del mundo en el que estás**, no al mundo 1.
- ~~**Los requisitos de mundo se miden contra Wins ganadas de por vida (`TotalWinsEarned`), no contra el saldo** (2026-08-13)~~ — **revertido el 2026-08-19 por petición de diseño.**
- **Las Wins de un mundo son un precio, no una marca histórica** (2026-08-19). Se miden contra el **saldo** (`Wins`) y se **cobran** al desbloquear, exactamente igual que un Sticky Wrap o un cosmético: si un mundo cuesta 2.500, hay que tenerlas en ese momento y desaparecen al abrirlo. Consecuencia directa: **el desbloqueo dejó de ser automático**. Cobrar solo, en el instante en que el saldo cruza el precio, le vaciaría las Wins a quien las estaba ahorrando para un wrap; ahora el jugador pulsa `UNLOCK` en la pantalla del portal y el servidor cobra en `ProgressionService.TryUnlockWorld`. Lo que ya se abrió sigue siendo permanente: gastar Wins después no vuelve a cerrar nada. `GameConfig.WorldRequirements` distingue los dos tipos con `Spend`: puerta (`Rebirths`, se comprueba) y precio (`WinCost`, se cobra). `RefreshWorldUnlocks` solo concede los mundos **sin precio**. `TotalWinsEarned` se sigue guardando y replicando como histórico, pero ya no decide ningún desbloqueo.
- **El nivel requerido para el Rebirth es también el nivel máximo** (2026-08-19). Al alcanzar el techo del Rebirth actual, el Level deja de subir hasta renacer, y la barra del HUD lo dice (`Level N MAX` / `REBIRTH!`, barra llena). Es claridad, no balance: el jugador ve sin ambigüedad que ya cumple el requisito. La **Stickiness sí sigue subiendo** por encima, y tiene que hacerlo — los blockers de las últimas salas piden mucho más que el último umbral de nivel del ciclo. Los perks (velocidad, radio) se congelan con el Level porque se calculan desde él. Un solo sitio decide el techo: `GameConfig.ClampLevelToCap`, que usa el servidor en `refreshLevel` y el HUD para saber cuándo pintar `MAX`.
- **La primera sala de cada mundo empieza en requisito 0.** Un jugador recién renacido llega con Stickiness 0; si la sala inicial del mundo 2 pidiera 500 se quedaría encerrado, sin nada que recoger, hasta volver al mundo 1 a pie.
- **El `SpawnLocation` de los mundos que no son el inicial va desactivado.** Uno habilitado entra en el sorteo de Roblox y mandaría allí a jugadores que no han desbloqueado el mundo. Quien viaja o reaparece lo coloca `WorldService` por teleport, con dos vías (cambio de atributo y `CharacterAdded`) porque el orden entre "carga el perfil" y "aparece el personaje" no está garantizado.
- **`GameConfig` y el Workspace llevan divergiendo en el mundo 1, y manda el Workspace** (2026-08-13). Los blockers piden lo que dice su atributo `RequiredStickiness` (`25/150/450/1000/2500/6000/10000/14000/20000/50000`), no el `BlockerRequiredStickiness` de `GameConfig.Zones` (`50/180/…/4000`); igual con `WinReward`. El único consumidor del valor de config es `HUDController`, así que **hoy la barra del HUD miente en el mundo 1**. En el mundo 2 los dos números se pusieron a coincidir a propósito. Pendiente de decidir si se alinea el mundo 1.
- **No usar `Highlight` para estado por objeto.** Roblox renderiza como máximo 31 a la vez, los deshabilitados también ocupan slot, y no existe API para subir el límite (petición abierta en el DevForum desde 2021, sin respuesta a noviembre de 2024). Un tope por debajo de ese límite deja parte de la sala sin marcar, que se lee peor que no marcar nada. Para estado por objeto: atenuar los colores propios del prop. Los Highlight solo para elementos únicos, como el objeto enfocado — y para los **blockers**, que son tres por vuelta (ver la nota de props reales).
- **El nombre de la plantilla es el único identificador de un objeto** (2026-08-19). No hay ids paralelos: el `Name` de la plantilla en `ReplicatedStorage/Assets/Collectibles` es lo que apunta el `ObjectValue` del pool de la sala, lo que viaja como `TemplateName` en la recogida y lo que busca `AttachmentService` como `ProxyKey` en `Assets/AttachmentProxies`. Una plantilla que no está declarada en `GameConfig.CollectibleTypes` funciona igual, como variante visual con `GainMultiplier = 1`. Añadir un prop es: plantilla en `Collectibles`, proxy con el mismo nombre en `AttachmentProxies`, y un `ObjectValue` en el pool de la sala. Ningún servicio cambia.
- **Cuánto se encoge un objeto al pegarse lo decide el propio prefab** (2026-08-19). `Assets/AttachmentProxies/<Prop>/AttachmentScale` es un NumberValue en [0, 1]: la fracción de su tamaño original con la que se pega. **No toca el tamaño con el que aparece en la sala**, y esa separación es justo lo que pedía diseño — los props reales se ven grandes en el suelo y razonables en la pila. `Model:ScaleTo(0)` es inválido, así que el 0 del diseño se traduce a `MinimumAttachmentScale = 0.005`. Un proxy sin el valor conserva el comportamiento viejo (la escala sale del tramo de requisito en `ScaleTiers`), que es lo que mantiene vivos los placeholders de W2 y W3.
- **Toda plantilla de coleccionable tiene el pivote donde el objeto toca el suelo**, no en su centro (2026-08-19). Con props de hasta 40 studs no hay alternativa: un pivote central entierra medio árbol, porque el punto del slot es el mismo para un árbol que para una bellota. `GameConfig.Collection.SpawnGroundDrop` baja el visual la altura del slot para que se apoye; la posición **lógica** del objeto no se mueve, así que el radio de recogida es el de siempre.
- **Los proxies de pegado dejaron de ser de una sola parte** (2026-08-19). Eran cubos sustitutos; ahora son los props de verdad, con malla y detalle. Se admiten hasta `MaxPartsPerProxy` y `AttachmentRenderer` suelda las partes extra a la principal una sola vez, al crear el clon. **Anclar y desanclar es una operación sobre toda la pieza**: una sola parte anclada deja el ensamblaje entero anclado y la pieza se queda flotando donde nació.
- **Un prop con `SurfaceAppearance` puede ignorar `Color`** (2026-08-19). Si trae ColorMap, escribirle el color no pinta nada y el rojo/verde de "puedo o no puedo" muere en silencio. Por eso cada puerta del mundo 1 lleva un `StateHighlight` authored y `BlockerController` escribe **los dos canales**: el `Color` de las partes (único canal de los blockers greybox de W2/W3) y el Highlight cuando existe.
- **El tamaño del prop manda sobre cuántos caben en una sala.** Una sala mide 62 × 70 studs. `ItemPlacementService` avisa él solo (`produced N slots but the room asks for M objects`) y ese aviso es el criterio, no la intuición: con props medianos las salas bajaron de 32 a 20 objetos y la de props grandes a 10. **Es una bajada real de objetos por vuelta**; la palanca para recuperarla es agrandar la `PlacementArea`, no bajar la separación.

## Reglas de trabajo acordadas

Las reglas completas y permanentes están en `AGENTS.md`; deben leerse al iniciar futuras sesiones de este proyecto.

1. Actualizar `PLAN_MVP.md` al terminar cada fase o subfase verificable.
2. Marcar un check únicamente después de comprobarlo en Studio.
3. Añadir notas breves de lo construido, pruebas realizadas, problemas y próximo paso.
4. Actualizar esta memoria cuando cambie una decisión técnica o de alcance.
5. Inspeccionar antes de editar para no sobrescribir trabajo existente.
6. Mantener nombres técnicos y código en inglés; documentación y comunicación en español.
7. No agregar features fuera del plan sin señalar primero el impacto en la semana.
8. Probar camino exitoso, rechazo y limpieza/reinicio siempre que sea posible.
9. Diseñar conexiones, tareas, tablas e instancias con límites y limpieza explícitos para evitar leaks.
10. Mantener servicios desacoplados y APIs pequeñas; balance y límites deben salir de configuración.
11. Favorecer módulos portables y documentar sus contratos para reutilizarlos en futuros juegos.
12. No construir UI permanente por código; crearla en `StarterGui` o en el contenedor authored correspondiente y enlazarla desde controladores.
13. No reconstruir geometría permanente por código; conservar modelos/props authored en el DataModel para poder colocarlos y editarlos manualmente.

## Jerarquía creada

```text
ReplicatedStorage/
  Shared/
    GameConfig
    CollectibleTemplates
    Remotes/
      PickupFeedback, BlockerFeedback, RebirthRequest, RebirthFeedback
      RoomItemsSync        -- servidor -> cliente: Load / Spawned / Consumed / Unload
      PickupRequest        -- cliente -> servidor: solo el id del objeto
  Assets/
    Collectibles/          -- plantillas authored que el cliente clona
      _RequirementBillboard
      ToyBlock, ToyBall, ToyCar
      Pillow, Sock, Book
      Apple, Mug, Plate
ServerScriptService/
  Server/
    DataService, ProgressionService, RoomService
    RoomSettingsReader     -- lee la config authored del Workspace
    ItemPlacementService   -- slots por sala, cacheados
    ItemPlanner            -- reparto equitativo, puro
    RoomItemService        -- sesión por (jugador, sala)
    PickupService          -- validación autoritativa del pickup
    AttachmentService, BlockerService, FinishService, WinPedestalService
    WorldRegistry          -- mundo -> instancias del mapa (lobby, spawns, ReplayPad)
    WorldService           -- portal, remotes de viaje y bypass temporal
StarterGui/
  StickyHUD/
    StatsPanel/                    -- bloque central abajo, todo en Scale
      BlockerProgress              -- "TOY CHEST 7 / 50"
      Stickiness                   -- numero grande abreviado
      WrapLabel                    -- pegamento equipado en su color, con su +N
      MultiplierLabel              -- "x1.5 Stickiness (Rebirths)"
      LevelBar/Fill+LevelText+AmountText
      BoostRow/Boost1..Boost4      -- placeholder, sin dev product detras
    CounterStack/                  -- arriba-izquierda, como la referencia
      RebirthCounter/Icon+Amount
      WinsCounter/Icon+Amount
    PickupFeedback
    RebirthOpenButton/ReadyBadge   -- abre la pantalla; el punto se enciende si hay Rebirth
    RebirthScreen/Window/          -- modal authored: Title, CloseButton,
                                   -- MultiplierBefore/Arrow/After,
                                   -- LevelCapBefore/Arrow/After, Warning,
                                   -- ProgressBar/Fill+LevelText+AmountText,
                                   -- RebirthButton, Message
StarterPlayer/
  StarterPlayerScripts/
    Client/
      HUDController
      RebirthController    -- dueño de la pantalla de Rebirth y del remote
      CollectibleRenderer  -- clones locales con pool
      ObjectLabelController-- billboard + Highlights pooled
      CollectibleController-- sync + loop de proximidad
      BlockerController
Workspace/
  StuckToYou/
    Zones/
      ToyRoom/
        Geometry/
        Blockers/ToyChest
        StartSpawn
        PlacementArea      -- volumen invisible donde pueden caer objetos
        RoomSettings/      -- Configuration editable a mano
          TotalObjects, MinSeparationStuds
          ObjectPool/      -- un ObjectValue por tipo permitido
```

## Contrato reusable — sistema de collectibles

### Componentes

- `ProgressionService`: estado de run y fórmula de ganancia; no conoce Parts ni UI.
- `CollectibleFactory`: construye la representación runtime; no otorga progreso.
- `CollectibleService`: descubre spawns por tag, valida contactos y concede progreso; delega toda disponibilidad a `SpawnService`.
- `ObjectLabelController`: presentación rojo/verde por jugador; no modifica estado de servidor.
- `HUDController`: observa atributos y feedback; no conoce la implementación interna de los servicios.
- `AttachmentService`: escucha el evento de colección y mantiene la representación soldada; no concede Stickiness.

### Requisitos para portarlo a otro juego

1. Copiar los cinco módulos/controladores y el bootstrap correspondiente.
2. Proveer en `GameConfig` las secciones `Tags`, `Network`, `PlayerDefaults` y `Collection`.
3. Crear un RemoteEvent con el nombre configurado en `Network.PickupFeedbackRemote`.
4. Etiquetar spawn markers con `ItemSpawn` y darles attributes `ZoneId` y `RequiredStickiness`.
5. Cada carpeta de spawns requiere una carpeta hermana `Collectibles` para las instancias runtime.

La representación puede reemplazarse editando `CollectibleFactory`; las reglas de progreso pueden cambiarse en `ProgressionService`; ninguno de esos cambios requiere reescribir el otro sistema.

## Contrato reusable — salas y pool de spawns

### Componentes

- `RoomService`: registra zonas tagged, valida su estructura y expone configuración/folder por `ZoneId`; no conoce pickups ni progreso.
- `SpawnService`: mantiene handles lógicos, objetivo activo, reservas, cooldown y selección balanceada; no crea Parts ni otorga Stickiness.
- `CollectibleService`: adapta cada Part runtime a un handle mediante un callback `SetActive`.

### Contrato de una zona

El Folder necesita tag `StickyZone`, attribute `ZoneId`, entrada correspondiente en `GameConfig.Zones` y los folders hijos `Geometry` y `Blockers`. Para que aparezcan objetos hace falta además el `PlacementArea` (BasePart invisible, tagueado) y el `RoomSettings` con su `ObjectPool`. Cada zona configura `EntryStickiness`, `CollectibleRequirements`, `TotalObjects`, `MinSeparationStuds` y `WinReward`.

### Garantías verificadas

- Un solo pool compartido por zona, con conteos acotados por los markers authored.
- No se clonan ni destruyen collectibles durante el respawn; solo cambia su estado activo.
- La selección inicial prioriza el mínimo de objetos elegibles y conserva una reserva cuando el contenido lo permite.
- La reposición excluye el handle recién consumido, rota hacia otra instancia y restaura el objetivo activo tras el cooldown.
- Las tareas diferidas se cancelan al retirar un handle o destruir el servicio.

## Contrato reusable — pila visual

### Entradas

- Evento interno de colección con `CollectibleId`, `ZoneId` y `RequiredStickiness`.
- Character estándar con `UpperTorso`, `Torso` o `HumanoidRootPart`.
- Configuración `Attachments` con rings cuyo total coincida con `MaxVisualAttachments`.

### Garantías

- Máximo de 30 records y partes activas por jugador, configurable.
- Todas las partes son massless y no participan en collision, touch o query.
- Slots deterministas; ningún offset aleatorio puede tapar la cámara de forma impredecible.
- Limpieza en `CharacterRemoving`, `PlayerRemoving` y `Destroy()`.
- Pool libre acotado; nunca crece por encima de `PoolCapacity`.
- Los pickups posteriores al límite solo cambian un contador escalar acotado y actualizan tamaños en un máximo de cinco ocasiones.

### Para portarlo

Copiar `AttachmentService`, proporcionar un origen de eventos compatible y reemplazar únicamente `GameConfig.Attachments`. El servicio no depende de Toy Room, Stickiness como fórmula, HUD ni persistencia.

## Contrato reusable — blockers por jugador

### Componentes

- `PlayerCharacterUtil`: validación común de contacto, Character, Humanoid y distancia.
- `BlockerService`: valida requisito y guarda completitud por jugador; no modifica geometría global.
- `BlockerController`: presenta elegibilidad y absorción local; no concede progreso.
- `HUDController`: consume feedback y el nuevo `CurrentZoneId`.

### Contrato del objeto

El objeto etiquetado como `StickinessBlocker` necesita attributes:

```text
BlockerId
ZoneId
NextZoneId
RequiredStickiness
```

Puede ser Model o BasePart. El servidor conecta sus BaseParts, evita completados duplicados y mantiene el blocker intacto para otros jugadores. Para portarlo, se reemplaza `GameConfig.Blockers`, la fuente de progreso y el comportamiento visual cliente.

El cliente conserva el aspecto authored para restaurarlo después de un reset, pero pinta todas las piezas con `IneligibleColor` o `EligibleColor` según el progreso local. El descubrimiento inicial usa tres pases finitos durante 2.5 s y se cancela en `Destroy()`; no existe polling permanente.

## Contrato reusable — cierre y replay de una vuelta

- `FinishService` escucha `BlockerService.ConnectAbsorbed`; no conoce Parts de Refrigerator ni concede progreso desde el cliente.
- `GameConfig.Finish` define blocker/zona final, nombres de spawns, delay, debounce y distancias. Cambiar la ruta no exige editar el servicio.
- `ProgressionService.AwardWin` solo modifica el dominio de progreso; la idempotencia por vuelta pertenece a `FinishService` y se activa antes de premiar.
- `AttachmentService.ClearPlayerVisuals` y `BlockerService.ResetPlayerRun` permiten reiniciar sin destruir el character ni duplicar lógica privada.
- El folder físico de Finish requiere `FinishSpawn` y `ReplayPad`; no necesita tag `StickyZone` porque no administra un pool de collectibles.
- Las conexiones, locks, cooldowns y threads diferidos se limpian en `PlayerRemoving`, `CharacterAdded` y `Destroy()`.

## Registro de trabajo

### 2026-08-03 — Lunes, Bloque 1

- Estado inicial: lugar vacío, sin scripts; solo objetos predeterminados.
- Construcción: estructura mínima, GameConfig y Toy Room en greybox.
- Validación: módulo requerido con éxito; assertions de Level, Wrap, Rebirth y conteo de tags superadas.
- Próximo paso exacto: crear collectibles desde los 12 spawn markers e implementar pickup autoritativo con debounce y respawn de 2 segundos.

### 2026-08-03 — Lunes, Bloque 2

- Construcción: servicios de progreso y collectibles, factory runtime, HUD, feedback y labels por jugador.
- Pruebas: arranque sin errores; 12 collectibles presentes; pickup elegible; rechazo por requisito; actualización HUD/Level; rojo/verde; respawn de 2 s; teardown limpio al salir de Play.
- Seguridad: ningún RemoteEvent concede progreso; el premio nace únicamente de una validación server-side de `Touched`.
- Ciclo de vida: conexiones rastreadas, cooldown por Player limpiado en `PlayerRemoving`, threads de respawn cancelables y tablas acotadas a jugadores/spawns activos.
- Próximo paso exacto: implementar pila visual mediante un `AttachmentService` independiente, con slots configurados, pool/reuso, reset seguro y máximo de 30 objetos.

### 2026-08-03 — Lunes, Bloque 3

- Construcción: evento interno de colección, `AttachmentService`, 30 slots por rings, pool de 60 y crecimiento acotado tras el límite.
- Pruebas: pickup real, propiedades físicas, welds, slots únicos, stress hasta 30 piezas/Stickiness 175, navegación con pila completa, reset y reuso del pool.
- Resultado de reset: Stickiness 0, Level 1, visuals 0, growth 0 y 30 piezas recuperadas.
- Teardown: Studio volvió a Edit sin instancias runtime ni errores del juego.
- Próximo paso exacto: implementar el blocker reutilizable, hacer que Toy Chest cambie a verde en 50 y abra la salida al absorberse; después medir y ajustar la duración.

### 2026-08-03 — Lunes, cierre

- Construcción: `PlayerCharacterUtil`, `BlockerService`, `BlockerController`, RemoteEvent de feedback y `ExitPreview`.
- Pruebas: rechazo en 0, estado verde en 54, absorción de las tres partes, salida transitable, servidor intacto para otros jugadores, reset completo y consola limpia.
- Bug encontrado: el registro cliente podía adelantarse a la replicación de descendientes. El retry inicial de 0.5 s fue insuficiente en el playtest manual y después se reforzó con descubrimiento por attributes.
- Medición: ruta óptima con WalkSpeed normal completada en 42.1 s y 36 movimientos de pickup. Se espera 45–60 s para una persona nueva, pendiente de comprobación manual.
- Próximo paso exacto: ejecutar `MANUAL_TEST_CHECKLIST.md`; si Toy Room queda fuera de 45–60 s, tocar únicamente valores de `GameConfig` o distribución de spawn markers antes de iniciar el martes.

### 2026-08-03 — Corrección de blocker visual

- Síntoma reportado manualmente: `ZONE OPEN!` funcionaba, pero Toy Chest no cambiaba a verde ni desaparecía.
- Diagnóstico: carrera de replicación exclusivamente cliente; `BlockerService` y el estado server-side estaban correctos.
- Causa raíz: el retry único de 0.5 s no garantizaba que tag, attributes y BaseParts estuvieran disponibles juntos.
- Solución: `BlockerController` usa descubrimiento por `BlockerId` como fallback en inicio, cambio de Stickiness y evento de absorción.
- Coste: un scan inicial; no hay polling permanente. Los scans adicionales solo ocurren mientras `records` está vacío.
- Pruebas: ciclo completo de absorción/reset y dos reinicios adicionales; tres inicializaciones correctas, consola limpia.

### 2026-08-03 — Martes, fase 1

- Construcción: `RoomService`, `SpawnService`, tag `StickyZone`, `EntryStickiness` por zona y orden explícito de inicialización/teardown en `Main`.
- Refactor: `CollectibleService` dejó de controlar timers y disponibilidad; ahora consume/restaura handles del pool y conserva la autoridad sobre la concesión de progreso.
- Balance authored de Toy Room: 12 markers, 10 activos, 2 reservas y 4 accesibles a Stickiness 0; `Spawn_09` es la reserva accesible.
- Pruebas: arranque sin errores, pickup real, conteo constante de 12 instancias, retorno a 10 activas y restauración de 4 elegibles después del cooldown.
- Bug encontrado por prueba: la primera selección podía escoger otra vez el handle consumido. Solución: parámetro `excludedHandle` en la selección de reemplazo; regresión de rotación superada.
- Alcance protegido: `Lobby` permanece fuera del tag `StickyZone` y su geometría no fue modificada.
- Próximo paso exacto: construir Bedroom y Kitchen con el mismo esquema, colocar sus 12 markers y blockers, y verificar cada zona antes de conectar la vuelta completa.

### 2026-08-03 — Martes, fase 2

- Construcción: Bedroom y Kitchen lineales, paletas greybox distintas, ruta visible, 12 markers por sala, Bed y Refrigerator tagged/configurados.
- Balance: cinco markers del tier de entrada permiten cuatro activos más una reserva; cada pool mantiene objetivo 10 sin churn.
- Ruta probada con gameplay real: `51 → ToyChest → Bedroom → 183 → Bed → Kitchen → 503/Level 20/CosmicGlue → Refrigerator → FinishZone`.
- Rechazo: Bed a 0 no cambió progreso, completitud ni zona.
- Reset: progreso, wrap, zona, pile y los tres blockers regresaron a estado inicial.
- Corrección: estado inelegible ahora pinta el blocker completo en rojo; tres reintentos iniciales acotados resuelven la carrera de replicación con varias salas.
- Teardown: las tres carpetas `Collectibles` quedaron vacías en Edit; no persistieron instancias runtime.
- Alcance protegido: `Lobby` fue modificado en paralelo por el usuario y se mantuvo completamente fuera de nuestras escrituras.
- Próximo paso exacto: crear FinishZone físico, otorgar una sola Win al completar Refrigerator y reiniciar la vuelta sin duplicar premios.

### 2026-08-03 — Martes, fase 3

- Construcción: FinishZone físico, `FinishService`, resumen de run por atributos, Win visible en HUD y ReplayPad.
- Arquitectura: `FinishService` depende de contratos públicos pequeños; todo identificador, delay, distancia y nombre de punto sale de `GameConfig.Finish`.
- Idempotencia: el estado por jugador se bloquea antes de `AwardWin`; cinco contactos repetidos con Refrigerator mantuvieron Wins en 1.
- Pruebas: rechazo del pad antes de completar; ruta real completa hasta 503/Level 20/CosmicGlue; Win, resumen, pile clear y teleport; rechazo final tras reset; replay completo y nuevo pickup; muerte/respawn conservando Wins.
- Ciclo de vida: threads de teleport cancelables, conexiones y tablas limpiadas por jugador y en `Destroy`; no hay polling ni instancias runtime persistentes al volver a Edit.
- Presentación: los tres blockers se restauran rojos después del replay y el HUD muestra `WINS` desde atributos replicados.
- Alcance protegido: FinishZone no se etiqueta como `StickyZone` y `Lobby` permaneció fuera de las escrituras aunque siguió cambiando por colaboración en vivo.
- Próximo paso exacto: cerrar el tutorial ambiental de una línea y ejecutar diez vueltas para registrar duración por zona y ajustar solo configuración/balance.

### 2026-08-03 — Martes, fase 4

- Construcción: tutorial ambiental no bloqueante frente al spawn; se conservaron las franjas amarillas de navegación existentes.
- Corrección de medición: `BlockerService` separa `zoneStartedAtByPlayer` de `runStartedAtByPlayer`; el evento entrega `ZoneSeconds` y `RunSeconds`.
- Stress: 10/10 vueltas reales de física, 10 Wins exactas, 10 replays y estado final limpio en el mismo servidor.
- Tiempos acelerados min/prom/max: Toy `10.53/11.66/13.63 s`, Bedroom `8.88/9.80/10.72 s`, Kitchen `6.13/6.82/7.62 s`, total `27.20/28.28/29.28 s`.
- Pools después del stress: tres veces `12 total / 10 activos`; pile 0, Stickiness 0, Level 1 y blockers rojos/visibles.
- Decisión de balance: no ajustar con tiempos de teletransporte automatizado. La meta humana de 3–5 min y Toy Room 45–60 s continúa como prueba manual explícita.
- Teardown: Collectibles runtime 0 en las tres salas, consola limpia y Studio en Edit. `Lobby` permaneció fuera de las escrituras.
- Próximo paso exacto: persistencia server-side de Wins/Rebirths y flujo Rebirth 0 → 1 con pruebas de fallo, reconexión simulada y cierre seguro.

### 2026-08-03 — Miércoles, fase 1

- Construcción: `DataService`, configuración de perfil, remotes de Rebirth, validación server-side y guardado inmediato de Rebirth.
- UI authored: `StarterGui.StickyHUD` contiene el HUD existente y el nuevo `RebirthPanel`; `HUDController` dejó de crear la jerarquía visual por código.
- Prueba de rechazo: solicitud al inicio no mutó Rebirths, Stickiness ni estado de vuelta.
- Prueba exitosa: ruta física completa hasta `503 / Level 20 / Win 1`; Rebirth conservó la Win, produjo `Rebirths 1`, reseteó run/zone/pile y guardó `Wins 1 / Rebirths 1` en el backend mock.
- Multiplicador: el primer pickup Basic Glue posterior otorgó `+1.5` real.
- Regresiones corregidas: señal de carga perdida entre consulta y espera; zona lógica incorrecta después de Rebirth; warning de espera no acotada al clonar el HUD authored.
- Teardown: Studio volvió a Edit sin collectibles runtime. El smoke final arrancó sin errores ni warnings propios.
- Limitación explícita: no se habilitó acceso cloud desde Studio; falta validar salida/reentrada contra DataStore real y fallo de API antes de marcar el bloque completo de datos como cerrado.
- Próximo paso exacto: ejecutar prueba cloud controlada de persistencia/reconexión y luego continuar con 3–6 clientes simulados.

### 2026-08-03 — Miércoles, fase 2

- Cloud: acceso existente confirmado mediante `GetAsync` de solo lectura; no se cambiaron ajustes del place.
- Datos faltantes: un perfil nuevo en el store aislado cargó defaults sin error.
- Persistencia/reconexión: el primer servidor guardó `Wins 1 / Rebirths 1`, liberó la sesión al cerrar y el segundo servidor recuperó los valores exactos con multiplicador 1.5x.
- Respawn: muerte y character nuevo conservaron únicamente los datos persistentes; Stickiness, Level, zona, pile y estado de vuelta quedaron reiniciados.
- Fallos: con dos errores mock la carga tuvo éxito en el tercer intento; con tres errores agotó el límite, marcó `DataLoadFailed` y no creó un estado guardable con defaults.
- Configuración final restaurada: store de producción, mock habilitado solo en Studio e inyección de fallos en cero.
- Smoke final: perfil mock cargado, servicios inicializados sin errores y Studio devuelto a Edit.
- Próximo paso exacto: ejecutar test local con 3–6 clientes y medir carreras de touch, disponibilidad por zona y limpieza por jugador.

### 2026-08-06 — Rebirth con pantalla propia y repetible

- **El Rebirth ya no exige terminar la vuelta.** El documento de diseño dice "unlocked when the player reaches the required Level" y punto; la exigencia de `RunCompleted` era un añadido del código. Se retiró de `FinishService.requestRebirth`. Como consecuencia el remote quedó disponible durante toda la partida y necesitó su propio freno: `GameConfig.Rebirth.RequestDebounceSeconds`.
- **El level cap pasó de tabla a fórmula.** `LevelCapByRebirth = {[0]=20, [1]=25}` se cambió por `BaseLevelCap + rebirths × LevelCapPerRebirth`, más `LevelCapOverrides` para excepciones a mano. El `.md` dice "Rebirth 0: Level 20, Rebirth 1: 25, etc.": eso es una fórmula, y una tabla de dos filas la contradecía en cuanto alguien renacía.
- **El sistema estaba muerto tras el primer Rebirth y no lo decía.** `LevelThresholds` tenía exactamente 20 entradas, así que el nivel máximo alcanzable era 20 — pero el cap del Rebirth 1 era 25. Un jugador con `Rebirths = 1` no podía volver a renacer nunca y la UI solo mostraba "LEVEL 25 REQUIRED" para siempre. El tope duro `MaximumImplementedRebirth = 1` tapaba el síntoma sin arreglar la causa. Ahora `GetLevelCap` devuelve `nil` cuando el techo cae fuera de los niveles generados, y ese `nil` es la única fuente del tope: `GetMaximumRebirth()` lo deriva. **Regla: un requisito que el jugador no puede cumplir debe apagar la función, no quedarse esperando.**
- **Los niveles altos se generan, no se escriben.** `GameConfig.LevelExtension` continúa la curva afinada a mano (20 umbrales) hasta el nivel 100 creciendo el último salto un 10 % por nivel. Con eso hay 17 Rebirths disponibles. La curva generada es mecánica, no diseñada: sirve para que el Rebirth sea repetible, no como balance final.
- **`execute_luau` tiene su propia caché de módulos** (2026-08-06). Un `require` desde la herramienta MCP devuelve una instancia nueva del ModuleScript, no la que está corriendo: `ProgressionService.GetTrackedPlayerCount()` daba 0 con un jugador dentro. No sirve para leer ni mutar estado vivo de un servicio. Para probar progreso hay que recorrer la ruta real; mover el `HumanoidRootPart` encima de objetos elegibles y dejar que el sensor del cliente y la validación del servidor hagan su trabajo funciona bien (88 pickups reales en 29 s).
- **Un pickup fallido casi siempre es el requisito, no la posición.** Al depurar el farmeo, el primer objeto no se recogía: `Collectible_1` pedía 25 de Stickiness y el jugador tenía 0. Antes de sospechar del sensor o del teleport, mirar `RequiredStickiness`.
- La pantalla vieja (`RebirthPanel`, panel pequeño que solo aparecía al completar la vuelta) fue sustituida por `RebirthOpenButton` + `RebirthScreen`. `HUDController` soltó todo lo de Rebirth salvo el aviso de la línea de feedback; el dueño ahora es `RebirthController`.
- Próximo paso exacto: comprobar la conservación de Wins sobre el flujo nuevo con `Wins > 0`, y afinar la curva de los niveles 21+ con playtest.

### 2026-08-06 — El Level deja de caer al reiniciar la vuelta

- **Síntoma reportado:** pisar un pedestal de Wins devolvía al inicio y ponía Stickiness en 0 (correcto), pero también el Level en 1 (no era la idea).
- **Causa:** el Level no se guardaba, se *derivaba*. `AddStickinessFromCurrentWrap` hacía `state.Level = GetLevel(state.Stickiness)`, así que al poner la Stickiness a 0 el Level caía con ella. `ProgressionService.ResetRun` además lo forzaba a 1 explícitamente junto con el Sticky Wrap.
- **Arreglo:** el Level pasa a ser la **marca más alta del ciclo de Rebirth**, no una lectura de la Stickiness actual. `AddStickinessFromCurrentWrap` usa `math.max(state.Level, GetLevel(state.Stickiness))` y `ResetRun` ya solo toca la Stickiness y la zona.
- **Quién comparte `ResetRun`:** el pedestal de Wins, el ReplayPad y el respawn tras morir, todos vía `FinishService.returnToStart`. El arreglo aplica a los tres: morir tampoco baja el Level. El Rebirth es lo único que devuelve Level y Wrap al principio, y lo hace en `TryRebirth`, no en `ResetRun`.
- **Consecuencia buscada:** el Sticky Wrap también se conserva entre vueltas, así que cada vuelta después de cobrar arranca más rápida — coherente con "Makes the next run faster" del documento de diseño. Verificado: primer pickup tras el pedestal dio `+8` (SuperGlue conservado) en lugar de `+1`.
- **Consecuencia a tener en cuenta:** como la Stickiness sí vuelve a 0, subir de nivel exige alcanzar el umbral **dentro de una misma vuelta**. Cobrar a mitad de camino no acumula hacia niveles altos; lo que deja es la velocidad. Es lo que hace que el pedestal sea una decisión y no un trámite.
- Pruebas: pedestal de 1 Win real tras absorber el Toy Chest → `Stickiness 183 → 0`, `Level 12` intacto, `Wrap SuperGlue` intacto, `Wins 0 → 1`, teleport al inicio y zona `ToyRoom`; el Level siguió subiendo de 12 a 14 en la vuelta siguiente; muerte y respawn conservaron `Level 14`; Rebirth con `Level 20` devolvió `Level 1 / BasicGlue` y conservó `Wins 1` con multiplicador `1.5x`. Consola limpia y teardown correcto.
- Esto cierra el pendiente anterior de comprobar la conservación de Wins con `Wins > 0` sobre el flujo nuevo.

### 2026-08-06 — Sticky Wraps: se compran con Wins, no se desbloquean por nivel

- **La implementación anterior contradecía el documento de diseño.** El `.md` dice "Wins are used to unlock Sticky Wraps" y "The **equipped** Sticky Wrap determines how much Stickiness the player gains". El código hacía lo contrario: `UnlockLevel` 1/5/10/15 y `GetStrongestWrap(level)` forzaba siempre el más fuerte, así que no había nada que equipar ni nada en lo que gastar las Wins.
- **Modelo nuevo:** `Basic Glue` viene de fábrica y no se puede comprar ni perder; `Strong / Super / Cosmic` se compran con Wins (3 / 10 / 25) y se equipan a mano. `GameConfig.GetStrongestWrap` y `UnlockLevel` desaparecieron; en su lugar están `GetDefaultWrap`, `IsDefaultWrap` y `GameConfig.Wraps`.
- **El Level y el Wrap quedaron desacoplados del todo.** El Level ya solo sirve para el techo del Rebirth. Comprobado: 80 recogidas seguidas pasando de Level 5 a 8 siguieron dando `+1`, donde antes el nivel habría subido el pegamento solo.
- **Los wraps comprados se persisten** (`OwnedWrapIds` y `EquippedWrapId` en el perfil). Se pagan con Wins, que son moneda persistente: perderlos al reconectar sería robar. El Rebirth sí los borra, como pide el `.md`, y las Wins no se tocan, así que el jugador conserva con qué volver a comprarlos.
- **Los atributos no admiten tablas**, así que el conjunto comprado viaja como una cadena separada por comas en el atributo `OwnedWrapIds`. Una sola señal de cambio en vez de una por wrap; el cliente la parte y siempre añade el de fábrica por su cuenta, aunque el atributo aún no haya replicado.
- **`WrapService`** solo valida la forma de la petición y frena el spam; las reglas viven en `ProgressionService`. `DataService.normalizeWrapIds` descarta cualquier id que no exista hoy en el catálogo, así que un perfil viejo o manipulado no puede meter un wrap inventado.
- **La lista de la tienda se clona de `_WrapRow`**, plantilla authored dentro de `WrapScreen`. Añadir un pegamento es tocar `GameConfig.StickyWraps`, no la pantalla. La plantilla vive **fuera** del `ScrollingFrame` a propósito: un `UIListLayout` reserva hueco también para los hijos invisibles, así que dejarla dentro habría dejado un espacio vacío arriba de la lista.
- Pendiente explícito: **el viaje completo de ida y vuelta de los wraps persistidos no está verificado**. El mock de DataStore de Studio vive en el VM del servidor y muere al salir de Play, así que no se puede probar reconectando. Sí está verificada la escritura (`DataLastSavedWraps` mostró `BasicGlue,StrongGlue` tras comprar y `BasicGlue` tras el Rebirth). Falta repetir la prueba cloud con almacén aislado, como se hizo con Wins/Rebirths.
- Pendiente de diseño: el `.md` pide que los wraps "**visibly change the player's sticky coating, material, or attachment effect**". Hoy el wrap solo se lee por color (nombre del HUD, `+N` de cada recogida y la franja de la tienda). El recubrimiento visual del personaje es trabajo de arte y no entró aquí.

### 2026-08-06 — El `.md` añade Trails y Auras: la fórmula pasa a tener tres capas

- **La ganancia dejó de ser un solo multiplicador.** Ahora es `WrapBaseGain × (RebirthMultiplier + TrailAddition) × AuraMultiplier`. El **Trail suma** al multiplicador base y el **Aura multiplica** el resultado ya combinado. Confundir esas dos operaciones es el error fácil: por eso la fórmula entera vive ahora en `GameConfig.GetStickinessGain` / `GetBaseMultiplier` y nadie más multiplica a mano. Verificada contra el ejemplo textual del documento (`3 × 4.5 × 2.0 = 27`).
- **Trails y Auras no se implementaron.** `ProgressionService.getTrailAddition` y `getAuraMultiplier` devuelven el neutro (`0` y `1`) y son el único punto del cálculo que habrá que cambiar. Hoy el resultado es idéntico al anterior en todas las combinaciones probadas.
- **Nuevo atributo `StickinessMultiplier`**: el multiplicador efectivo del jugador. Hoy coincide con `RebirthMultiplier`; en cuanto existan Trails y Auras dejará de coincidir. **La UI debe leer ese atributo, no recalcular la fórmula por su cuenta** — hoy `HUDController` y `RebirthController` llaman a `GetRebirthMultiplier` directamente, y eso solo es correcto mientras no haya trail ni aura. El de Rebirth sigue teniendo sentido en la pantalla de Rebirth, que compara antes/después de renacer.
- **Precio de Cosmic Glue corregido a 30 Wins**: el documento ahora fija `0 / 3 / 10 / 30` y el 25 era una elección previa mía.
- **Trails y Auras no se resetean con el Rebirth.** El documento sigue diciendo solo "Resets unlocked Sticky wraps". Con precios de 15–100 Wins tiene sentido, pero conviene confirmarlo antes de implementarlos.
- **Velocidad y radio de recogida quedan fuera de la fórmula.** Los bonus de Trails y Auras sobre movimiento y radio no cambian la ganancia por objeto: van sobre `Humanoid.WalkSpeed` y `GameConfig.Collection.PickupRadius`. Ese radio es hoy una constante global **validada en servidor** (`PickupValidationSlack`), así que hacerlo por jugador obliga a tocar también `PickupService`.
- **Conflicto sin resolver:** el documento cambió la compra de Sticky Wraps a **placas físicas en el lobby** ("stepping into the respective plate"), mientras que Trails y Auras sí son botón en el HUD. Lo implementado para Wraps es botón + pantalla. La lógica no estorba — `TryBuyWrap`/`TryEquipWrap` ya son API de servidor y unas placas serían otro llamador —, pero falta decidir si las placas sustituyen la pantalla o conviven con ella.

### 2026-08-06 — Los Sticky Wraps se equipan pisando placas del lobby

- **El documento manda: placas, no botón.** Los Wraps se compran y equipan pisando una placa del lobby. La pantalla del HUD se conservó como catálogo y porque es el patrón que reutilizarán Trails y Auras, pero la ruta oficial es la placa.
- **Una sola regla para las dos rutas.** `ProgressionService.RequestWrap` es el punto de entrada único: compra si no lo tienes, equipa si ya lo tienes, y devuelve cuántas Wins faltan. La placa y la pantalla lo llaman igual. Antes el cliente decidía si mandaba `Buy` o `Equip`; ahora solo pide el wrap y el servidor resuelve. Menos superficie que validar y dos rutas que no pueden divergir.
- **Las ocho placas se identificaron por su firma geométrica**, no por nombre: eran las únicas partes `7×1×7` en color `(255,176,0)` dentro de `Zones/Lobby/Geometry`. El resto de partes amarillas del lobby son rampas y suelos de otros tamaños. Quedaron renombradas `WrapPad_<WrapId>`, tagueadas `WrapPad` y con attribute `WrapId`. **`Lobby2` no se tocó.**
- **El cartel de cada placa lo pinta el cliente**, no el servidor: "comprado" y "equipado" son estado por jugador, así que un cartel server-side mostraría el estado de otro. Misma razón por la que el color de la placa se cambia desde el cliente — las escrituras del cliente sobre partes del Workspace son locales. Plantilla authored en `ReplicatedStorage/Assets/LobbyUI/_WrapPadSign`, con `Size` en Scale (studs) por la misma lección de las tarjetas de requisito.
- **Cuatro wraps nuevos** para llenar las ocho placas: Quantum `+50`/75, Nova `+120`/150, Galaxy `+300`/300, Infinity `+750`/600. Los cuatro del documento se mantuvieron intactos. Ganancia ×2,5 por peldaño (la pendiente que ya traían los originales) y precio ×2, que deja la eficiencia casi plana.
- **`Touched` no dispara si el personaje aparece encima de una placa sin moverse** (2026-08-06). Al probar teletransportando el personaje justo sobre la placa no ocurría nada; cayendo desde arriba sí. Roblox necesita contacto real, no solapamiento estático. Vale para cualquier pad del proyecto: al probar pads por script, hay que **caer** sobre ellos, no aparecer encima.
- **Techo de ingreso de Wins.** Los pedestales dan 1/3/10, así que una vuelta rinde como mucho 10 Wins pase lo que pase con el wrap equipado. Las vueltas se acortan mucho al subir de pegamento pero el ingreso no escala, así que la parte alta de la escalera (Infinity = 600 Wins ≈ 60 vueltas) es larga. Si se quiere acortar, o suben los pedestales o bajan los precios altos.

### 2026-08-06 — Regla dura de autoría, y la Stickiness solo se pierde con el Rebirth

**1. Si es fijo, se crea en el editor.** Regla nueva en `AGENTS.md` (sección 5.1). Todo lo que el jugador ve, en UI o en el mundo, y existe en cantidad fija y conocida, debe estar creado a mano en el DataModel. El código no lo instancia en runtime.

- El criterio es *quién decide el aspecto*: cantidad fija → instancias authored una por una; cantidad variable o lista repetida desde configuración → plantilla authored que el código clona.
- **Que el contenido sea distinto por jugador no justifica crearlo por código.** Las escrituras del cliente sobre instancias del Workspace son locales, así que un cartel authored y compartido muestra a cada jugador su propio texto y color. Ese fue exactamente el error con los carteles de las placas: se clonaban por jugador "porque el estado es por jugador", cuando bastaba con uno authored por placa.
- El motivo práctico: si el cartel nace en runtime, subirlo unos studs o agrandarlo obliga a editar código en vez de arrastrarlo en Studio.
- **Corregido:** los 8 `WrapSign` son ahora hijos authored de cada placa en `Zones/Lobby/Geometry`. Se borró la plantilla `Assets/LobbyUI/_WrapPadSign` y `WrapPadController` dejó de clonar: localiza el cartel, valida su contrato y solo escribe texto y color. Tamaño, offset, fuente y layout son del editor. Si falta el cartel, avisa y deja esa placa sin etiqueta en vez de generar una.

**2. La Stickiness solo se pierde con el Rebirth.** Cobrar en un pedestal de Wins ya no la reinicia; tampoco morir ni el ReplayPad.

- `ProgressionService.ResetRun` dejó de tocar el progreso: ahora solo reposiciona la zona lógica. Stickiness, Level y Wrap pertenecen al ciclo de Rebirth y únicamente `TryRebirth` los devuelve al principio. El documento de diseño solo lista "Resets Stickiness" bajo Rebirth, y del pedestal solo dice que concede Wins y teletransporta.
- **Lo que sí debe seguir reiniciándose en cada vuelta son los blockers.** Los atributos `CompletedZone_*` son los que autorizan cobrar un pedestal, así que sin `BlockerService.ResetPlayerRun` se podría cobrar el mismo pedestal en bucle sin moverse. Verificado: tres intentos seguidos de cobrar sin rehacer la ruta no pagaron nada; rehacerla sí.
- Consecuencia de diseño: la vuelta pasa a ser "vuelvo con toda mi Stickiness, atravieso los blockers al toque y llego más lejos a cobrar un pedestal mayor". Es lo que hace que subir de Sticky Wrap se note entre vueltas.
- La pila visual sí se sigue limpiando al volver al inicio. Es presentación, no progreso, y además evita que los adjuntos de blocker —que están protegidos del reciclado— se acumulen vuelta tras vuelta hasta llenar los 36 slots.
- **Pendiente señalado:** la Stickiness y el Level siguen sin persistir entre sesiones (`initializePlayer` los arranca en 0 y 1). Con la regla nueva de "solo el Rebirth resetea", salir y volver a entrar es hoy la única forma de perderlos sin renacer. Si diseño quiere coherencia total, hay que añadirlos al perfil de `DataService`.

### 2026-08-06 — HUD central de Stickiness, nivel y multiplicador

- **`ProgressPanel` fue sustituido por `StatsPanel`**, un bloque centrado abajo con el número de Stickiness, el wrap equipado, el multiplicador efectivo y la barra de nivel, más `CounterStack` arriba a la izquierda con Rebirths y Wins. Calcado en forma y color a la referencia de simulador que dio diseño.
- **Todo el bloque nuevo va en Scale puro: ni un solo Offset en `Size` ni en `Position`.** Es lo que hace que escale en móvil sin una pasada aparte. Donde hacía falta forma fija —iconos circulares, badges— se usó `UIAspectRatioConstraint`, que no mete píxeles. Los únicos píxeles que quedan son los `UIStroke.Thickness`, que la API no permite en Scale.
- **La barra mide el tramo dentro del nivel actual**, no el total acumulado: `current = Stickiness - thresholds[Level]`, `span = thresholds[Level+1] - thresholds[Level]`. Contra el total la barra no se movía de forma legible. En el último nivel generado no hay siguiente umbral: se llena y muestra `MAX`.
- **El HUD lee el atributo `StickinessMultiplier`, no `GetRebirthMultiplier`.** Cierra el pendiente que dejó la sesión de Trails y Auras: cuando existan, el número seguirá siendo correcto sin tocar la UI.
- **Los números se abrevian con tres cifras significativas** (`14.1K`, `1.51K`, `3M`). Detalle que cuesta un bug: los ceros de cola solo se recortan si de verdad hay parte decimal — hacerlo a ciegas convierte `"100"` en `"1"`.
- **`RebirthOpenButton` y `WrapOpenButton` pasaron de Offset a Scale.** No entraban en el encargo, pero `CounterStack` los pisaba y, siendo Offset, en móvil se habrían quedado clavados en píxeles encima de los contadores.
- **`PickupFeedback` subió a `0.6` de altura**: caía justo encima del número grande de Stickiness.
- **`screen_capture` agota el tiempo de espera en este lugar**, tanto en Play como en Edit. La verificación visual se hizo por medidas: `AbsolutePosition`/`AbsoluteSize` de cada nodo y un test de intersección de rectángulos entre los cinco elementos de primer nivel del HUD. Sirve para detectar solapes y texto que no cabe (`TextFits`), no para juzgar el aspecto.
- Pendiente: los 4 botones de `BoostRow` son placeholder sin dev product; los `Icon` de los contadores son `ImageLabel` vacíos esperando arte; y falta una revisión a ojo en el emulador de dispositivos.

### 2026-08-10 — Perks de progresión: velocidad y radio de adherencia

- **Sistema nuevo `PerkService`** (servidor) + `GameConfig.LevelPerks`. Dos perks que crecen con la progresión: `WalkSpeed` sobre el Humanoid y `PickupRadius`, que es el radio con el que los objetos se adhieren al jugador.
- **La fórmula copia la forma de tres capas de la Stickiness, a propósito:** `[ Base + Rebirths × PerRebirth + escalones de nivel ] × (1 + Trail) × (1 + Aura)`. Vive entera en `GameConfig` y nadie la reimplementa. El Rebirth sube el **suelo permanente**; el nivel sube por escalones dentro del ciclo; Trail y Aura son porcentajes.
- **Trails y Auras siguen sin implementarse, pero el enganche ya está hecho y es distinto del de la Stickiness.** El documento define bonus de **movimiento y radio** además del multiplicador: Trail +10/15/20/30% de velocidad; Aura +10/15/20/25% de velocidad y +5/10/15/20% de radio. `PerkService` tiene `getTrailSpeedBonus`, `getAuraSpeedBonus` y `getAuraRadiusBonus` devolviendo `0` — mismo patrón que `getTrailAddition`/`getAuraMultiplier` de `ProgressionService`. **Al implementarlos hay que rellenar los cinco puntos, no los dos de la ganancia.**
- **El Level se reinicia con el Rebirth, así que los perks bajan al renacer; el suelo no.** `PerRebirth` (2.0 velocidad / 0.6 radio) se eligió midiendo esa caída, no en abstracto: como el techo de nivel crece 5 niveles por Rebirth, el pico de cada ciclo crece y un suelo pequeño hacía la caída enorme a media partida (−14 de velocidad con `PerRebirth = 1`). Con 2 arranca en −1.75, culmina en −9.25 hacia el Rebirth 6 y **vuelve a cero en el 11**, cuando el suelo alcanza el techo. La base va 16 → 18 → 20 → … → 40 y nunca baja.
- **Dos techos por perk, y son distintos a propósito.** `Maximum` topa la base; `MaximumWithBonuses` topa el valor final. Si fueran el mismo número, equipar Trail y Aura no haría nada en el endgame. 40 × 1.3 × 1.25 = 65 es demasiado para salas de ~35 studs, de ahí el 52.
- **El radio de recogida ya no es una constante global.** `PickupService` valida contra `PerkService.GetPickupRadius(player)`; el sensor del cliente lee el atributo replicado. `Collection.PickupRadius` se conserva como el valor del nivel 1 y es de donde sale el `Base` del perk, para no tener dos fuentes de verdad. Esto cierra el pendiente que dejó anotado la sesión de Trails y Auras.
- **`FocusHighlightMaxDistance` pasó de techo a mínimo:** `max(14, radio + margen)`. Con el radio creciendo, un foco fijo haría que el objeto se recogiera antes de que el Highlight lo marcara y el jugador nunca vería a qué apuntaba.
- **`PerkService` publica el factor cosmético aparte** (`WalkSpeedBonus`, `PickupRadiusBonus`) además del valor. El HUD lo necesita para prometer el incremento **del jugador**: sin él, alguien con Aura vería anunciada la subida de alguien sin ella. Mismo principio que `StickinessMultiplier`: la UI lee, no recalcula.
- **Balance manual disponible sin tocar código:** `Curve` con pares `{ Level, Value }` sustituye a la fórmula por escalones (el aporte del Rebirth se sigue sumando encima), y `Enabled = false` clava el perk en `Base`. Los dos verificados.
- **`screen_capture` sí funciona en este lugar** (contradice lo anotado el 2026-08-06). Las capturas de los chips del HUD se tomaron sin problema, en Play.
- **Los `GetAttributeChangedSignal` son diferidos.** Leer un perk en el mismo instante en que cambia el nivel devuelve el valor anterior. Es menos de un frame y no se percibe jugando, pero invalida cualquier medición por script que no ceda un `task.wait()`. Costó una lectura falsa de "los perks van con retraso".
- **El VM del plugin cachea sus propios `require`.** `require` desde `execute_luau` devuelve una instancia **distinta** de la que usa el juego: `RoomItemService.GetStats()` reportaba `Sessions=0` con la sala cargada, y `CollectibleRenderer.GetEntries()` devolvía `0` con 24 objetos en pantalla. Para leer estado de servicios en marcha hay que crear un `Script` temporal (corre en el VM del juego) o leer instancias reales del DataModel. Vale para cualquier prueba futura por MCP.
- **Pendiente:** `BoostRow` sigue siendo placeholder y se encogió de `0.28` a `0.205` de alto para hacer sitio a `PerkRow`. Si algún día lleva dev products detrás, conviene revisar que los cuatro botones siguen legibles en móvil.

### 2026-08-10 — Sticky Rest Zone, el área AFK del lobby

- **El documento de diseño cambió y con él la definición.** `Stuck to You- One-Week Prototype.md` añadió la sección "How the Rest Zone Works". Sustituye la interpretación provisional del `PLAN_MVP` (§1 y §12.4: "Finish / Rest Zone" como cierre de vuelta, **sin AFK**). Ahora sí es economía pasiva, y está implementada. **Si algo cita el `PLAN_MVP` para decir que no hay AFK, está desactualizado.**
- **La Rest Zone no tiene fórmula propia, y es a propósito.** El documento define `RestZoneGain = NormalStickinessGain × RestZoneMultiplier`, y ese primer término es literalmente `GameConfig.GetStickinessGain`. Así que `ProgressionService.AddStickinessFromCurrentWrap` recibe un `sourceMultiplier` opcional y la placa le pasa el suyo. **Consecuencia importante: cuando se implementen Trails y Auras, el descanso los hereda solo.** Ningún sitio nuevo que recordar.
- **Cinco tiers en el documento, siete placas en el lobby.** Mismo caso que los wraps (4 en el doc, 8 placas) y misma solución: los cinco del doc intactos, la escalera extendida. La diferencia: aquí la extensión **frena** la curva (x20, x30 tras el x10 del doc) en vez de acelerarla. Inventar por encima del techo que diseño especificó pide ser conservador — subir un número luego es fácil, bajarlo cuando los jugadores ya lo probaron no.
- **Los tiers 4 y 5 son Robux en el documento.** Los dev products siguen fuera de alcance y no hay `ProductId`. Cada tier de pago lleva un `RequiredRebirths` de respaldo y existe `RestZones.RequirePurchaseForPaidTiers`, hoy en `false` para que la escalera entera sea jugable y balanceable. **Ponerlo en `true` al monetizar** y decidir entonces si las placas 6-7 también son de pago.
- **`TickSeconds = 3` es el único número de balance que importa.** Los multiplicadores solo significan algo contra esa cadencia. Con un ritmo activo de 1-2 objetos/s: la placa libre rinde 17-33% de jugar, la última gratuita (Rebirth 5) llega a la par y solo las de pago la superan. Es el arco que pide el documento. **El loop se sostiene porque las Wins solo salen de jugar**, y son las Wins las que compran los wraps que multiplican también el descanso.
- **Ocupación por caja, nunca `Touched`.** Además de que `Touched` no dispara si el personaje aparece encima sin moverse (ya registrado con las placas de wrap), no avisa de forma fiable **al salir**, que es justo lo que el documento exige que corte el ingreso al instante. Un solo `Heartbeat` estrangulado a 0.25 s comprueba posiciones en el espacio **local** de la placa, así que una placa girada a mano en Studio sigue funcionando sin tocar código.
- **El cobro va separado de la comprobación de ocupación.** Se acumula tiempo y se cobra al cruzar `TickSeconds`; cambiar de placa reinicia el acumulado para no arrastrar tiempo de una placa peor a una mejor. El desbloqueo se revalida en cada cobro, no solo al entrar.
- **El descanso tiene que sonar distinto de recoger.** Es un ingreso que llega solo cada pocos segundos; con el sonido de recogida tal cual, parecen recogidas fantasma. El cobro reutiliza ese sonido **con el tono bajado a 0.7 y sin combo** — un pulso tranquilo, no una racha. Entrar se celebra como una compra; salir deja el resumen `RESTED +N`, que es lo único que ve quien vuelve del AFK.
- **Las 7 placas son cantidad fija → carteles authored uno por uno** (regla 5.1). Cada `RestSign` se clonó del `WrapSign` de la tienda para que las dos alas del lobby se lean como el mismo sistema; el código solo escribe texto y color. El reparto placa → tier vive en el atributo `RestZoneId`, así que reasignarlo es arrastrar un valor en el Explorer.
- **Pendiente:** falta playtest humano. Todos los ritmos están calculados contra un ritmo activo **estimado** de 1-2 objetos/s, no medido con una persona; la medición que hay en `PLAN_MVP` es de un bot en ruta óptima y no sirve para esto.

### 2026-08-10 — Compras de Rest Zone con placeholders, y pasada de sonido

- **El flujo de compra con Robux está entero, con ProductId de marcador de posición** (`1000000004`–`1000000007`). Prompt al pisar una placa bloqueada, `ProcessReceipt`, concesión, persistencia y desbloqueo. Al crear los dev products se pegan los ids y ya funciona; hay un warn al arrancar que los lista para que no se olvide.
- **Lo comprado con Robux no se pierde con el Rebirth.** `OwnedRestZoneIds` vive en el perfil y `TryRebirth` no lo toca, a diferencia de los wraps. Es la única cosa del juego que sobrevive a un Rebirth además de las Wins.
- **`ProcessReceipt` es un callback único del juego y no se puede leer, sólo escribir.** No hay forma de detectar si otro sistema lo instaló antes; intentarlo tira un error. Hoy lo posee `RestZoneService`. **Si aparece un segundo tipo de producto hay que mudarlo a un servicio de compras que enrute por `ProductId`**, o las compras del primero desaparecen sin ningún aviso.
- **Sólo devuelve `PurchaseGranted` si la concesión y su guardado salieron bien.** En cualquier otro caso `NotProcessedYet`, para que Roblox reintente y el jugador no pierda lo que pagó.
- **Cobrar Wins y renacer eran los dos silencios grandes del juego.** `WinPedestalService` sólo disparaba un `BindableEvent` de servidor —nada llegaba al cliente— y el Rebirth únicamente pintaba texto en el HUD. Los dos eran las recompensas más importantes del loop y pasaban sin sonido. Ya no.
- **La música se decide por dónde está el cuerpo, no por la zona lógica.** Se mide contra las partes `ItemPlacementArea` (el suelo jugable authored de cada sala). Ni `CurrentZoneId` ni `CollectibleController.GetZoneId()` sirven: **las dos siguen diciendo `ToyRoom` mientras el jugador está en el lobby**, que es justo cuando debe sonar la otra pista. Me costó un diagnóstico entero descubrirlo.
- **Las dos pistas suenan siempre y sólo cambia el volumen.** `Play`/`Stop` reiniciaría la pista cada vez que se cruza el pasillo, y eso se oye como un corte. Dos streams de música no cuestan nada al lado de esa costura.
- **Histéresis asimétrica en el cambio de pista**: entrar en una sala cambia al momento, salir espera 3 s. Sin eso, el pasillo entre salas y los pedestales hacían parpadear la música dos veces seguidas.
- **El volumen de música es una sola cuenta con tres factores** (`MusicVolume × descanso × duck`) resuelta en un `Heartbeat` que se corta al llegar a destino. Con tweens sueltos sobre `SoundGroup.Volume`, dos efectos solapados dejan el volumen donde acabe el último en morir.
- **Dos bugs propios que sólo se ven probando de verdad:**
  - `bindUIClicks` leía `config.UIClickEnabled`, pero esa bandera está en `GameConfig.Audio` y `config` apunta a `GameConfig.Feedback`. Daba `nil`, la guarda salía y **todos los botones quedaban mudos sin un solo error en consola**. Lección: al añadir una bandera, comprobar a qué tabla apunta el `config` local del módulo que la lee.
  - `bindUIClicks` usaba `FindFirstChildOfClass("PlayerGui")` dentro de `Init`, cuando aún no existe. Ahora espera en su propio hilo; `Init` no puede ceder el hilo sin retrasar al resto de controladores.
- **Probar sonido por MCP es un problema de sincronización.** Un observador lanzado en una llamada separada casi siempre llega tarde al evento y da un falso negativo — me pasó tres veces y llegué a creer que los remotes estaban rotos. Lo que funciona: una sonda que **repite** el evento en ciclo, o un `Script`/`LocalScript` temporal que observe y haga `print`, leyendo después la consola. `VirtualInputManager` no está disponible desde el VM del plugin (falta capacidad `RobloxScript`), así que los clicks reales se hacen con `user_mouse_input`.

### 2026-08-11 — Escalado del HUD en móvil: dos layouts, los dos del editor

- **La variante móvil del HUD no está en código.** Son atributos `Compact*` en las mismas instancias authored, y `ResponsiveLayout` sólo elige cuál de los dos juegos de valores aplicar. Era la única forma de adaptar el layout sin romper la regla 5.1: quien quiera mover el panel en móvil arrastra un valor en el panel Attributes, no edita un módulo. El mapa atributo → propiedad vive en `GameConfig.UI.CompactAttributes`; añadir una propiedad adaptable es una línea allí más el atributo en Studio.
- **`TextScaled` y `TextWrapped` están acoplados en Roblox: poner `TextWrapped = false` apaga `TextScaled`.** Lo hice sobre las 51 etiquetas creyendo que el wrap era lo que partía el texto en dos líneas, y el HUD entero cayó a su `TextSize` base de 8 px. No hay aviso de ninguna clase. Si hace falta una línea sin partir, la solución es dar ancho a la caja, no quitar el wrap.
- **El problema real del texto ilegible eran las cajas, no la fuente.** Con `TextScaled` el tamaño de letra *es* el alto de la caja, así que una caja dimensionada sólo en escala se encoge con la pantalla y la letra con ella. `PerkRow` a `0.095` de alto son 11 px en un teléfono: por debajo de lo legible en cualquier resolución, sólo que en 1080p no se nota. El `UITextSizeConstraint` es el suelo, pero lo que arregla el fondo es agrandar la caja.
- **Los techos de texto se calibran contra la resolución que ya se ve bien.** Puestos a ojo, recortaban a 1080p y encogían el HUD de escritorio sin que nadie lo hubiera pedido. Se midieron los tamaños naturales a 1918×1080 y se pusieron los `MaxTextSize` justo encima: a esa resolución no recorta ninguno y el límite sólo entra en 1440p y 4K.
- **Un `UIPadding` en offset es una bomba de relojería en móvil.** `RebirthOpenButton` llevaba 10 px arriba y 10 abajo sobre un botón que en escritorio mide 59 px de alto y en teléfono 20: el texto se quedaba literalmente sin sitio. Mismo caso en los chips de perk (18 + 12 px sobre un chip de 180 de ancho). Regla práctica: si el elemento se dimensiona en escala, su padding también.
- **El panel de stats no va centrado en la pantalla sino en el hueco entre los controles táctiles.** El joystick come la esquina inferior izquierda y el botón de salto la derecha; el centro de lo que queda está unos píxeles a la derecha del centro real (`0.515`). Centrarlo en `0.5` dejaba 9-16 px del panel debajo del joystick.
- **Medir el layout no necesita Play.** Clonar el `ScreenGui` dentro de un `Frame` del tamaño exacto del dispositivo y leer `AbsoluteSize`, `TextBounds` y `TextFits` da los números reales de cualquier pantalla desde el modo Edit, incluidas las que no se pueden abrir en Studio. Es mucho más rápido y más preciso que mirar capturas.
- **`TextBounds` de una etiqueta vacía devuelve el `MinTextSize`, no el tamaño real.** Los chips de perk marcaban 8 px en todas las pantallas y parecía un bug del layout; lo que pasa es que su `Text` está vacío en la plantilla y lo llena `HUDController` en runtime. Cualquier medición de texto por script tiene que escribir antes el contenido más largo que el juego vaya a poner.
- **`start_stop_play` del MCP no completa con una sesión de live editing abierta** (`TGAndres369 joined live editing session`). Devuelve "Start play hasn't finished yet" indefinidamente y el Studio se queda en Edit. Queda pendiente la pasada en Play.
- **StarterGui se renderiza en el viewport en modo Edit**, así que `screen_capture` sirve para ver el HUD sin entrar en Play. Lo que no se ve son los textos que escribe el runtime, que siguen con el contenido de la plantilla.
- **Pendiente:** las zonas de los controles táctiles están estimadas a mano (Roblox no las expone); la confirmación real es un teléfono. Y las filas del inventario se construyen en `Init`, así que rotar el teléfono no les cambia el alto — el resto del HUD sí se readapta.

### 2026-08-11 — Carteles del mundo en studs, y el contorno de la pestaña activa

- **Un `BillboardGui` con `Size` en offset es el mismo bug que el HUD en escala, del revés.** El HUD en escala se encogía con la pantalla; el billboard en píxeles **no se encoge con nada**: ni con la pantalla ni con la distancia. En un teléfono, 260 px son el 39 % del ancho, y siguen siéndolo a 80 studs de distancia. Con `AlwaysOnTop = true`, varios carteles lejanos se apilan a tamaño completo tapando la escena. En studs escalan con el mundo y el porcentaje de pantalla que ocupan es idéntico en móvil y en escritorio.
- **El propio lugar ya tenía la respuesta.** Los `WrapSign` y `RestSign` del lobby (15 instancias) estaban en studs desde siempre y se veían bien; los de bloqueador y pedestal, en píxeles. Cuando la mitad de un sistema funciona y la otra no, mirar en qué se diferencian antes de inventar nada.
- **Eran 20, no 4.** La exploración inicial con `max_depth: 3` sólo mostró ToyRoom, Bedroom y Kitchen; hay puertas en `Zone4`…`Zone10` y un `WinPedestal` por pasillo. Un barrido genérico sobre `workspace:GetDescendants()` filtrando por "Size en offset" los cogió todos. Para cambios de este tipo, barrer por propiedad, no por lista de rutas.
- **Studio excluye los `BillboardGui` con `AlwaysOnTop = true` de `screen_capture`.** Los `RestSign` (`AlwaysOnTop = false`) sí salen en las capturas y los `RequirementBillboard` no, lo que me hizo creer un rato que el cartel había desaparecido al cambiarlo. Para verlos hay que desactivarlo temporalmente; para medirlos, leer el `AbsoluteSize` de su `TextLabel` con la cámara colocada, que además da el tamaño real en pantalla a cada distancia.
- **`ApplyStrokeMode.Contextual` en un `TextButton` contornea la letra, no el borde del botón.** `setActiveTab` ponía el `UIStroke` de la pestaña activa en blanco, y el texto ya era blanco: contorno blanco alrededor de letra blanca, que es lo que se veía "blando". Ahora va el dorado `255, 204, 64`. Antes de tocar el color de un `UIStroke` conviene mirar su `ApplyStrokeMode`, porque cambia por completo qué está pintando.
- **El viewport 3D de Studio no es la ventana.** `camera.ViewportSize` daba 749×361 mientras el `ScreenGui` medía 1918×1080. Para medir HUD vale el `AbsoluteSize` del `ScreenGui`; para medir billboards, el viewport de la cámara.

### 2026-08-13 — Sistema de mundos y Mundo 2

- **Un mundo es un lobby más su cadena de salas.** `GameConfig.Worlds` declara `LobbyFolderName`, `StartZoneId`, `FinishZoneId`, `FinalBlockerId` y `Requirements`; cada zona lleva su `WorldId`. Nada más cambia: los mismos servicios, los mismos tags, las mismas placas. Añadir un mundo 3 es una entrada en esa tabla, sus zonas con `WorldId` y la geometría clonada en el editor con los nombres que dice la entrada.
- **Tres sitios asumían un solo mundo y eran justo los tres que había que tocar:** `GameConfig.Finish.StartZoneId/ZoneId/FinalBlockerId` (se movieron a la entrada de mundo), `ProgressionService.ResetRun/TryRebirth` (mandaban siempre a `ToyRoom`) y `FinishService` (tres variables de módulo con el único `StartSpawn`, `FinishSpawn` y `ReplayPad`). Ahora los tres resuelven por el mundo del jugador.
- **`WorldRegistry` existe separado de `WorldService` por una razón concreta: el require circular.** `FinishService` necesita saber dónde está el inicio del mundo de un jugador, y `WorldService` necesita a `FinishService` para reiniciar la vuelta al viajar. Con la resolución de instancias en un módulo aparte y sin estado, las dependencias van en una sola dirección.
- **Los requisitos son un catálogo, no un `if`.** `GameConfig.WorldRequirements` traduce cada tipo (`Rebirths`, `TotalWins`) a la estadística que lo mide, y `EvaluateWorldRequirements` la usan **servidor y cliente**. Si la pantalla evaluara por su cuenta, acabaría enseñando un botón que el servidor rechaza.
- **El desbloqueo se mide contra Wins ganadas de por vida y es permanente.** Ver la decisión vigente: con el saldo, comprar un pegamento podría cerrar un mundo ya abierto.
- **El botón temporal de bypass** (`GameConfig.WorldTravel.DebugUnlockEnabled`) enciende el botón de la pantalla **y** la aceptación en el servidor. Ocultar el botón no es la seguridad: el servidor vuelve a mirar la bandera. Hay un `warn` al arrancar mientras siga encendido. **Apagarlo antes de publicar.**
- **El Mundo 2 está creado en el editor, no en runtime.** Se clonó en modo Edit el lobby completo (con sus 8 placas de wrap y 7 de descanso y sus carteles), las 10 salas, los 10 pasillos con pedestal, la FinishZone y el ExitPreview, desplazados `+900` en X. Los tags sobreviven al `Clone()`, así que las tiendas del lobby 2 funcionaron sin tocar una línea de código. Retintado girando el tono `+0.55` y subiendo un poco la saturación, dejando fuera las placas de tienda para que las dos alas se lean como el mismo sistema.
- **`Lobby2` se borró.** Era geometría duplicada sin un solo tag ni atributo, solapando el lobby real; sesiones anteriores la habían dejado sin tocar por precaución.
- **Descubierto al clonar: `GameConfig` y el Workspace del mundo 1 llevan tiempo divergiendo.** Los blockers reales piden `25/150/450/1000/2500/6000/10000/14000/20000/50000` y los pedestales pagan `1/3/10/20/30/50/75/100/150/300`; el config decía otra cosa. Manda el atributo. El mundo 2 se escaló sobre el terreno real (×10 en requisitos, ×15 en Wins) y sus dos fuentes se pusieron a coincidir, comprobado por script sala a sala.
- **Balance del mundo 2:** requisitos ×10 y Wins ×15. Esa diferencia entre los dos factores **es** el balance: pagar 15 veces más por 10 veces más esfuerzo deja el mundo 2 un 50 % más rentable por unidad de Stickiness. Si algún día se siente obligatorio o inútil, se mueve ese 15 y nada más. Los cuatro requisitos de objeto de cada sala se reparten al 0/25/50/75 % del tramo entre la entrada y la puerta, así que siempre hay algo que recoger al entrar.
- **Requisitos del mundo 2 hoy: 10 Rebirths y 5.000 Wins ganadas**, elegidos por el usuario como valores de partida para ajustar después.
- Pruebas en Play, con un jugador: portal abre la pantalla en los dos lobbies; viaje rechazado con el mundo bloqueado; bypass desbloquea y la fila pasa a `TRAVEL`; viaje al mundo 2 (spawn correcto, `W2_ToyRoom`, 24 objetos); recogidas reales; absorción del `W2_ToyChest` a 250 y paso a `W2_Bedroom`; pedestal pagando 15 Wins y devolviendo al inicio **del mundo 2**; muerte reapareciendo en el mundo 2; Rebirth conservando el mundo y dejando 6 objetos recogibles con Stickiness 0; compra de wrap y cobro de Rest Zone en el lobby 2; vuelta al mundo 1. Consola limpia y teardown sin restos.
- **Pendiente:** el viaje de ida y vuelta de los campos nuevos del perfil (`CurrentWorldId`, `UnlockedWorldIds`, `TotalWinsEarned`) no está verificado contra DataStore real, por la misma limitación de siempre: el mock de Studio muere al salir de Play. Falta la prueba cloud con almacén aislado, como se hizo con Wins/Rebirths.
- **Pendiente de decisión:** alinear el mundo 1 (config ↔ Workspace) o dejarlo. Mientras siga desalineado, la barra de bloqueador del HUD enseña números falsos en el mundo 1.

### 2026-08-13 — Monetización, Fase 0: un solo dueño de `ProcessReceipt`

El plan completo de monetización, con las 8 fases y qué referencia de UI pide cada una, vive en `PLAN_MONETIZATION.md`.

- **Auditoría:** de toda la sección Monetization del documento de diseño, lo único implementado eran las Premium Rest Zones (~90 %, con ProductId placeholder). Ni un gamepass, ni wraps premium, ni Double Win Plates, ni un solo dev product del HUD. Trails y Auras sí están completos, pero solo con Wins.
- **`MarketplaceService.ProcessReceipt` es un único callback en todo el juego y no se puede leer, solo escribir.** Ya estaba anotado en `RestZoneService` como deuda; se pagó antes de tocar ningún producto nuevo, porque el segundo sistema que lo instale borra al primero **sin un solo error en consola** y las compras de aquel dejan de entregarse mientras Roblox las reintenta para siempre. Ahora lo posee `PurchaseService` y cada servicio registra sus `ProductId`.
- **Registrar dos veces el mismo `ProductId` lanza.** No es un caso a tolerar: significa que dos servicios creen cobrar lo mismo y uno de los dos no lo hará. Es justo la clase de fallo que este servicio existe para hacer ruidoso.
- **Contrato del handler: `(player, receiptInfo) -> boolean`, y tiene que ser idempotente.** Devuelve `true` si ya se poseía lo comprado, para que un recibo reentregado se dé por procesado. Encima hay una segunda red: `DataService.ProcessedReceiptIds` guarda los `PurchaseId` ya cobrados (50, purga por los más viejos), que es lo que protegerá a los productos repetibles de las fases siguientes, donde el handler *no puede* ser idempotente por sí solo.
- **Solo se responde `PurchaseGranted` si la concesión **y** la marca del recibo quedaron guardadas.** Si el guardado falla, Roblox reintenta y el handler idempotente no vuelve a conceder nada.
- **La propiedad de un gamepass no se persiste en el perfil.** Roblox es la fuente de verdad: un pase reembolsado tiene que dejar de valer, y un booleano en el DataStore lo mantendría activo para siempre. `GamePassService` consulta al entrar con reintentos y escucha `PromptGamePassPurchaseFinished` para conceder en caliente, sin obligar a reconectar. Publica `OwnedGamePassIds` como cadena separada por comas, igual que `OwnedWrapIds`.
- **Un fallo de red al consultar propiedad no puede leerse como "no lo compré".** `queryOwnership` devuelve `nil` (desconocido) y no `false` cuando se agotan los reintentos, y avisa; solo un `false` de verdad marca no-propiedad.
- **`RestZoneService` mantiene su propio cooldown de prompt (8 s) además del de `PurchaseService` (3 s)**, y no es redundante: allí la llamada nace de un bucle de ocupación que corre cuatro veces por segundo mientras el jugador siga encima de la placa.
- **El VM del plugin cachea sus `require` entre sesiones de Studio, no solo dentro de una llamada.** `require(GameConfig)` devolvía una versión sin la tabla `Monetization` recién añadida. El truco que funciona para leer código nuevo desde `execute_luau`: **clonar el ModuleScript, requerir el clon y destruirlo**. Sirve también para probar un servicio aislado (registro, cooldowns, colisiones) sin tocar la instancia viva.
- Pruebas en Play con un jugador: arranque limpio con un único aviso de placeholders (6 ids), `OwnedGamePassIds` publicado, Rest Zone gratuita sin regresión (Stickiness 0 → 2 en 8 s), enrutado de dos productos, registro duplicado lanzando y `PromptProduct` frenado por cooldown. Teardown sin restos.
- **Sin probar hasta que existan los productos reales:** el cobro de un recibo de verdad y la deduplicación contra DataStore real.

### 2026-08-13 — Monetización, Fase 1: los dos gamepasses permanentes

- **`x2 Wins` (R$ 199) y `x1.5 Speed` (R$ 149).** El x1.5 sale de la referencia de UI que dio el usuario; las Wins duplicadas cuentan **para todo**, incluido `TotalWinsEarned` y por tanto el desbloqueo de mundos (decisión explícita del usuario).
- **El multiplicador del pase entra fuera del paréntesis cosmético, y esa es la decisión de diseño que importa.** `ApplyPerkBonus` recorta primero contra `MaximumWithBonuses` (52, el techo de siempre) y solo después multiplica por el pase, con su propio techo `MaximumWithGamePass = 65`. Así **comprar el pase no altera un solo número del jugador que no lo compra**: sin pase el multiplicador es 1 y la función se comporta exactamente igual que antes de existir. Meterlo dentro del mismo paréntesis habría obligado a subir el techo común y a rebalancear Trails y Auras.
- **65 y no 78 (=52×1.5).** 78 studs/s cruza una sala de ~35 studs en menos de medio segundo: el personaje se pasa de largo los objetos y la cámara no acompaña. Con 65 el pase entrega su x1.5 íntegro mientras la velocidad recortada no pase de ~43 —o sea casi toda la partida— y en el endgame se queda en +25% sobre el gratuito, que es donde menos falta hace porque el radio ya barre media sala. Medido: L1 R0 `16 → 24`; L20 R2 `23.75 → 35.62`; L60 R11 con todo equipado `52 → 65`.
- **`AwardWins` ahora devuelve cuánto concedió de verdad.** Con el x2, el pedestal anunciaba su cifra authored mientras el jugador recibía el doble: mentirle justo en el instante en que acaba de pagar. `WinPedestalService` anuncia lo concedido y manda `BaseReward` aparte para poder celebrar la duplicación. **Regla general: si un multiplicador puede cambiar una cantidad, quien la anuncia tiene que recibirla de vuelta, no reusar la que pidió.**
- **`GameConfig.GetPerkGamePassMultiplier` existe porque `ApplyPerkBonus` no sabe qué pase mueve qué perk.** Probando descubrí que pasarle el x1.5 de velocidad al radio de adherencia lo subía de 12 a 15 sin quejarse. No era un bug vivo —`PerkService` ya devolvía el neutro para el radio— pero era un foot-gun servido para las fases de boosts temporales. Ahora el mapa perk→pase vive en un solo sitio y ni el servidor ni el HUD pueden equivocarse.
- **`WalkSpeedPassMultiplier` se publica aparte de `WalkSpeedBonus`.** Fundirlos en un solo factor daría un número equivocado en cuanto uno de los dos toque su techo, porque recortan contra techos distintos.
- **La propiedad de un pase no se persiste** (ya anotado en Fase 0), así que `PerkService` la lee del atributo replicado `OwnedGamePassIds` y lo añade a sus `PROGRESSION_ATTRIBUTES`: comprar el pase mueve el WalkSpeed en el momento sin que nadie avise al servicio. `ProgressionService`, en cambio, consulta `GamePassService` directamente: un premio concedido en el hueco entre entrar y resolver la propiedad leería el atributo vacío y pagaría de menos.
- **`GameConfig.Monetization.StudioDebugOwnedPassIds`.** Con ids placeholder no hay forma de comprar nada, así que el contenido de pago no se podría probar ni balancear hasta el día que existan los productos. Concede pases **solo en Studio**, con la puerta cerrada por `RunService:IsStudio()` y no por acordarse de vaciar la lista. Mismo criterio que `Data.UseStudioMockStore`. Vale igual para las fases siguientes.
- **El trofeo del lobby lo diseñé sin referencia** (el usuario no tenía): pedestal oscuro escalonado, columna, cuello, copa con asas y tapa, en oro metálico, sobre la plaza central entre las dos alas de tienda de cada lobby. Lleva `TouchZone` atravesable de 15 studs —acercarse basta, no hay que chocar con la geometría— y `TrophySign` con el mismo contrato que `WrapSign`: `Size` en studs y `AlwaysOnTop = false`.
- **El cartel del trofeo lo pinta el cliente**, como los de las placas de wrap y por la misma razón: "comprado" es estado por jugador y un cartel pintado desde el servidor mostraría el estado de otro.
- **Volvió a morder la carrera de replicación de descendientes.** `GamePassController` buscaba `TouchZone` una sola vez al descubrir el Model por su tag, y el tag llega con el Model antes que sus partes: los dos trofeos quedaban sin enlazar con un warn engañoso de "no tiene un TouchZone". Arreglado con `DescendantAdded` como vía de reparación. Es literalmente la regla que ya estaba escrita para `BlockerController`; **conviene comprobarla en cada sistema nuevo que descubra instancias por tag.**
- **`GetGamePassLabel` deriva el texto del botón del multiplicador real.** Nadie escribe "x2" a mano en una etiqueta: si mañana el pase pasa a x3, la UI lo dice sola.
- Pruebas en Play con un jugador: velocidad `16 → 24` con pase y vuelta a 16 al retirarlo; el radio sin tocar; pedestal authored de 1 Win pagando 2 con `TotalWinsEarned` y `LastWinReward` coherentes; fichas del HUD y cartel del trofeo en los dos estados; caminar contra el trofeo abre el prompt sin errores. Teardown limpio.
- **Sin probar hasta la Fase 7:** una compra real. Con `AssetId` placeholder la ventana de Roblox no abre nada y `PromptGamePassPurchaseFinished` nunca llega, así que la propiedad se simuló con la concesión de Studio.

### 2026-08-13 — Monetización, Fase 2: el precio vive en el mundo, no en un pop-up propio

- **No hay pantalla de confirmación de compra, y es decisión del usuario.** La ventana nativa de Roblox *es* la confirmación; lo que faltaba era que el mundo anunciara el precio. Esto retira del plan el `PurchasePromptScreen` que iban a heredar las fases 3, 4 y 5: cada pieza de pago lleva su precio encima y abre el prompt nativo.
- **El bug real que tapaba todo esto:** `IsRestZoneUnlocked` comprobaba el respaldo por Rebirths **antes** de mirar si el tier era de pago, así que con `RequirePurchaseForPaidTiers = false` devolvía siempre `RebirthRequired`. Consecuencia: **una placa de pago no enseñaba su precio ni abría su compra jamás**; el único camino visible era el gratuito, y el flujo de compra entero —implementado desde el 2026-08-10— era inalcanzable. Ahora, si el tier es de pago y el jugador no llega al Rebirth de respaldo, se le ofrece la compra; quien sí llega la usa gratis. **Regla: un orden de comprobaciones puede dejar una función de negocio entera muerta sin un solo error.**
- **La línea de estado dejó de repetir el precio y ahora dice la vía libre** (`OR REBIRTH 8`). Con el precio ya gritado arriba, repetirlo desperdiciaba el único renglón que podía decirle al jugador que también hay un camino sin pagar.
- **`PriceTag` authored en las 8 placas de pago.** El cartel creció hacia arriba y la tarjeta bajó a ocupar su sitio de siempre, compensando con `StudsOffset`: así las tres líneas de dentro conservan sus proporciones y no hubo que recolocarlas una a una.
- **No hay icono de Robux nativo utilizable.** `rbxasset://textures/ui/common/robux.png` y las otras tres rutas habituales dan `IsLoaded = false`. Se usa el texto `R$`, que ya era la convención del proyecto. Si algún día hay un asset propio, el `PriceTag` es authored y es cambiarlo por un `ImageLabel`.
- Pruebas en Play: las tres placas gratuitas siguen mostrando su requisito de Rebirth; las cuatro de pago muestran `R$ 99/199/399/799` y `OR REBIRTH 8/10/12/14`; pisar una de pago devuelve `Denied reason=PurchaseRequired robux=99` (antes `RebirthRequired`) y dispara el prompt. Consola limpia.

### 2026-08-13 — Monetización, Fase 3: Sticky Wraps premium

- **`Eternal Glue` (+1.500, R$ 199) y `Omega Glue` (+4.000, R$ 499).** Lo que venden **no es la ganancia, es que el Rebirth no se los lleve.** Los ocho normales se borran al renacer y hay que recomprarlos con Wins cada ciclo; estos se quedan puestos, así que la vuelta siguiente a un Rebirth arranca a toda velocidad en vez de volver al `+1`. Por eso el cartel dice `KEEPS ON REBIRTH` en vez de repetir el precio que ya está gritado encima.
- **`WinCost = 0` en un wrap premium no significa gratis, significa que no está a la venta por Wins.** Es la clase de valor que se malinterpreta sola: `TryBuyWrap` y `RequestWrap` lo cortan antes con `PurchaseRequired`, y el inventario del HUD pinta `R$ N` en vez del `🏆 0` que habría salido de leer el campo tal cual.
- **El Rebirth conserva el equipado si sobrevive.** `TryRebirth` solo devuelve al `BasicGlue` cuando lo que llevabas puesto se ha perdido de verdad. Obligar a volver a la placa a reequipar algo que nunca se perdió es un paso vacío.
- **`WrapService.PromptPremiumPurchase` es el punto único donde "esto se paga con Robux" se convierte en ventana.** La pantalla del HUD y las placas del lobby lo llaman con el mismo motivo devuelto por `RequestWrap`; las dos rutas no pueden divergir, igual que ya pasaba con `RequestWrap` para comprar y equipar.
- **Las placas nuevas se colocaron relativas a la última placa normal**, no con coordenadas absolutas: el mismo cálculo sirvió para los dos lobbies. Vale como método para cualquier pieza que haya que duplicar entre mundos.
- **Un premium no enciende el punto de aviso del botón de inventario.** Ese punto significa "ya puedes permitirte algo"; un premium se puede comprar siempre, así que lo dejaría encendido para siempre y dejaría de significar nada.
- **`registerPad` de `WrapPadController` cede el hilo esperando el cartel**, así que la última placa registrada se quedaba con el texto de la plantilla hasta el siguiente cambio de atributo. Ahora llama a `update()` al terminar. Vale la pena mirarlo en cualquier controlador que registre instancias una a una con `WaitForChild`.
- **Para probar estado vivo de un servicio desde MCP, la vía que funciona es crear un `Script` temporal con `Source` desde `execute_luau` en el datamodel Server** y leer la consola. El VM del plugin tiene su propia caché de `require` y devuelve instancias distintas de las que corren. Con eso se probaron `GrantWrap` y `TryRebirth` sin recorrer la ruta entera a mano. Las instancias creadas en Play no sobreviven al volver a Edit, así que no dejan rastro.
- Pruebas en Play: concesión del recibo (`OwnedWrapIds = BasicGlue,EternalGlue`, equipado); **supervivencia al Rebirth** (`BasicGlue,StrongGlue,EternalGlue` → `BasicGlue,EternalGlue`, equipado conservado, Level 30 → 1, Wins intactas); pisar la placa premium devuelve `PurchaseRequired Source=Pad`; carteles correctos en los dos estados; placas normales sin cambios. Teardown sin restos.

### 2026-08-13 — Monetización, Fase 4: Double Win Plates

- **20 placas, una reflejada al otro lado del pasillo frente a cada pedestal.** El pedestal dorado a un lado, la placa doble morada al otro. La posición sale de reflejar el pedestal contra el centro de su `FloorPad`, así que el mismo cálculo valió para los 20 sin escribir una sola coordenada.
- **Bandas de precio, no un producto por pedestal.** Hay 18 premios distintos entre los dos mundos; 18 dev products a mano serían imposibles de mantener alineados con los atributos authored. Cada placa resuelve su banda por el premio de su hermano, así que **subir el premio de un pedestal en el editor mueve su placa de banda sola**. Cinco bandas: 25 / 49 / 99 / 199 / 399 Robux.
- **La eficiencia sube con la banda a propósito** (0,8 → 22,6 Wins por Robux en el tope de cada una). Comprar el doble en el pedestal pequeño de tu banda es mal negocio y en el grande es bueno: la misma decisión que ya propone el sistema de pedestales, pasar de largo el pequeño y arriesgar por el siguiente.
- **El premio se lee del atributo authored del pedestal, jamás de `GameConfig.Zones`.** Era el riesgo anotado desde el principio de este plan: en el mundo 1 config y Workspace divergen, y leer la config habría hecho que las 10 placas del mundo 1 pagaran mal.
- **La reclamación se captura al pisar, no al llegar el recibo.** Entre el prompt y la entrega el jugador puede morir, rehacer la vuelta o desconectarse; lo que era cierto al pisar es lo único que se puede prometer. Si al llegar el recibo ya no se cumple, **se pagan las Wins igual** —el dinero ya está puesto— y lo que se pierde es el teletransporte. Sin reclamación viva se paga el tope de la banda: ante la duda, de más antes que de menos.
- **No hay doble cobro con el pedestal normal.** Cuando la reclamación es válida, cobrar teletransporta, y eso reinicia la vuelta y borra `CompletedZone_*`, así que el pedestal de al lado deja de ser cobrable. Cuando no lo es, ese atributo ya era falso. Las dos ramas cierran solas.
- **El x2 del gamepass se aplica encima del x2 de la placa**: `AwardWins` es el único punto de entrada, así que quien tenga los dos cobra x4. Coherente con que ambos se anuncien como "duplica tus Wins".
- **`PurchaseService.DebugSimulateReceipt`, solo en Studio.** Entrega un recibo falso por el camino real: mismo enrutado, mismo handler, misma deduplicación y mismo guardado. Sin esto **ningún producto puede probarse** hasta el día que existan los dev products, porque no hay forma de que Roblox entregue un recibo. Es la herramienta que hizo comprobables las bandas, el fallback y la deduplicación en una sola sesión.
- **Cuidado al probar con ids a mano:** mi primera sonda simuló la banda L sobre la placa de Kitchen, que es banda S. El sistema hizo lo correcto (no reconoció la reclamación y pagó el fallback de L, 600) y por un momento pareció un bug de la implementación. **Antes de sospechar del código, comprobar que el ProductId simulado es el de la banda que le toca a esa placa.**
- **Un rechazo silencioso en una pieza de pago se lee como una pieza rota.** `onWinFeedback` descartaba todo lo que no fuera `Claimed`, así que pisar la placa sin haber limpiado la zona no hacía absolutamente nada: ni sonido ni aviso. En el pedestal gratuito eso solo despista; en una placa que quiere cobrar, nadie compra algo que parece roto. Ahora avisa con `CLEAR THIS ZONE FIRST`, y el cobro doble se celebra distinto del normal (`+N WINS x2!` en morado).
- Pruebas en Play: rechazo sin zona limpiada; captura de reclamación con zona limpiada; cobro real en Kitchen (`+20` exactas, vuelta reiniciada y teletransporte) y en W2_Zone10 (`+9.000` exactas); recibo repetido pagando una sola vez; recibo sin reclamación pagando el fallback sin teletransportar; los 20 pedestales cayendo en su banda. Teardown sin restos.

### 2026-08-13 — Monetización, Fase 5: packs medidos en objetos y boosts temporales

- **Un pack de Stickiness con cantidad fija no puede funcionar en este juego.** `+3.000` es una fortuna para quien empieza y menos de un objeto para quien lleva Omega Glue (+4.000); en el mundo 2, con requisitos ×10, sería irrelevante desde el primer día. Los packs se miden en **objetos** y la cantidad sale de `GetStickinessGain`, así que escalan solos con el wrap, los Rebirths, el Trail y el Aura. Verificado: `Pack_S` da `+250` con Basic Glue y `+1.000.000` con Omega. **Mismo principio que la Rest Zone: no inventar una fórmula nueva, reutilizar la única que hay.**
- **El boost temporal no entra en el cálculo del pack.** Son dos compras distintas; multiplicarlas regalaría el doble por comprarlas en el orden correcto. Por eso existe `GetStickinessPerObject` aparte de la ruta normal de ganancia.
- **La caducidad se guarda como marca de tiempo absoluta, nunca como tiempo restante.** Guardar lo que queda hace que salir del juego congele el boost, y eso convierte un producto de 10 minutos en uno infinito para quien sepa desconectarse. Con `os.time()` el reloj corre igual dentro y fuera.
- **Comprar un boost ya activo suma tiempo, no lo reinicia** (techo de 4 h). Reiniciarlo haría que comprar dos seguidos valiera menos que comprar uno, que es la clase de sorpresa por la que la gente pide reembolsos.
- **El multiplicador se evalúa contra el reloj en cada uso, no contra un booleano guardado.** Un boost caducado deja de valer aunque el barrido todavía no haya pasado; el barrido de 5 s solo sirve para apagar el indicador y limpiar el perfil.
- **`BoostService` no aplica ningún multiplicador.** Lo publica en el atributo `ActiveBoosts` y lo leen `AddStickinessFromCurrentWrap` y `AwardWins`, los dos únicos puntos por donde entra progreso. Así la Rest Zone, los pedestales y las Double Win Plates lo heredan sin una línea aparte — y sin crear el ciclo que habría supuesto que `ProgressionService` requiriera a `BoostService`, que a su vez lo necesita para conceder los packs.
- **El precio de un pack es lo único del HUD que no puede escribirse en la plantilla**, porque la cantidad depende del jugador. `BoostController` repinta con cualquier cambio de wrap, Rebirths, Trail o Aura, y hace la misma cuenta que el servidor: todas sus entradas ya están replicadas y no hay nada que autorizar.
- Pruebas en Play: packs escalando (250 → 1M); recogida `+8.000` en vez de `+4.000` con boost; apilado sumando 600 s; `AwardWins(10)` concediendo 20 con el boost de Wins; caducados devolviendo el neutro y basura ignorada; HUD mostrando `+1M/+4M/+20M/+100M`, los dos boosts en `ACTIVE` y el chip contando atrás.
- **Sin verificar, misma limitación de siempre:** el viaje de ida y vuelta de `BoostExpiry` contra DataStore real. El mock de Studio muere al salir de Play.

### 2026-08-13 — Monetización, Fase 6: Skip Rebirth y Robux en los cosméticos

- **Lo que vende el Skip Rebirth no es saltarse el nivel, es no perder nada.** Sube `Rebirths` —y con él el multiplicador y el techo— y no toca Stickiness, Level, wraps ni cosméticos. Verificado: `Rebirths 0 → 1` con Stickiness 640, Level 22, `BasicGlue,SuperGlue` y el trail equipado intactos.
- **`TryRebirth` y `TrySkipRebirth` son dos funciones, no una con bandera.** Hacen lo contrario la una de la otra; compartirlas invitaría a que un cambio en el reinicio se colara en la versión de pago sin que nadie lo notara.
- **Sumar un Rebirth no tiene forma natural de ser idempotente, y eso obliga a un rollback explícito.** Conceder un wrap o un aura se puede repetir sin daño (ya lo tienes → `true`), pero un contador que se incrementa no. Si el guardado falla, `PurchaseService` responde `NotProcessedYet`, Roblox reentrega el recibo y sin deshacer el incremento el reintento sumaría un Rebirth de más sobre el ya aplicado en memoria. **Regla: cualquier concesión que no sea un booleano necesita o deduplicación previa o rollback en el fallo.**
- **Un `UIGradient` sobre un `TextButton` tiñe también la letra.** El texto blanco del Skip salía arcoíris sobre fondo arcoíris: invisible, y sin un solo error. Se mudó a un `TextLabel` hijo, que el gradiente del padre no toca — la misma solución que ya se había usado en las fichas de gamepass, y ya van dos veces que muerde. **Si un botón lleva gradiente, su texto va en un hijo.**
- **La vía de Robux en los cosméticos es una petición aparte (`UseRobux = true`), no un modo de la normal.** La fila tiene dos botones y cada uno hace una cosa; un solo botón que decidiera por su cuenta habría necesitado que el cliente supiera qué puede pagar el jugador, que es justo lo que este proyecto no le deja decidir. Comprobado que la vía de Robux no puede caer por accidente en la compra con Wins.
- **La fila del inventario acabó con tres formas** resueltas por la misma función: Wins + Robux (cosméticos), solo Robux (wraps premium) y solo Wins (el resto). Cuando solo hay una vía, ocupa la fila entera en vez de dejar un hueco al lado.
- Pruebas en Play: cosmético concedido con Robux sin descontar Wins; recibo repetido concediendo una sola vez; Skip conservando todo y subiendo el techo a 25; las tres formas de fila correctas en Trails, wraps normales y premium. Teardown limpio.

### 2026-08-18 — Eventos de mundo

- **El servicio no aplica ningún modificador: publica y ya.** `WorldEventService` escribe qué evento está activo y hasta cuándo en `ReplicatedStorage.Shared.WorldEventState`, y quien concede progreso o calcula un perk multiplica por lo que lea en el momento de usarlo. Es exactamente el reparto que ya usaban los boosts de pago, y es lo que hace que la Rest Zone, los pedestales y las Double Win Plates hereden el evento sin una línea propia: solo hay dos puertas de entrada de progreso (`AddStickinessFromCurrentWrap` y `AwardWins`) y las dos ya multiplican.
- **Atributos en vez de RemoteEvent.** Un evento es estado del servidor entero, no un mensaje. Los atributos replican solos, **llegan completos a quien entra a mitad de evento sin handshake ni petición al entrar**, y cuestan una replicación para todo el servidor en vez de un `FireAllClients` por cambio. El canal es una sola instancia authored (`Configuration`), no una creada por código.
- **El módulo lector (`Shared.WorldEvents`) vive en Shared y no abre ninguna puerta.** Un cliente puede falsear su copia de los atributos, pero las escrituras del cliente sobre instancias replicadas **no viajan hacia el servidor**: el multiplicador de verdad lo aplica el servidor con la suya, y `PickupService` sigue validando distancia contra el radio que calcula `PerkService`. Por el mismo motivo el disparador de admin (`AdminRequest`) puede vivir ahí sin ser un exploit.
- **El reloj es `Workspace:GetServerTimeNow()`, no `os.time()`.** Los boosts de pago usan `os.time()` porque se guardan en el perfil y tienen que sobrevivir a la sesión; un evento nace y muere dentro de un servidor, y lo que importa es que el reloj del cliente y el del servidor coincidan para que la cuenta atrás no mienta. El reloj local del jugador puede ir minutos desviado.
- **Cero bucles.** Una sola cadena de `task.delay` alterna arranque y fin; entre dos eventos el servicio no consume nada. Además la caducidad se evalúa contra el reloj **en cada consulta**, así que un temporizador perdido no dejaría un evento pagando para siempre.
- **Velocidad y radio necesitan techo propio (`MaximumWithEvent`).** El x2 del documento sobre el techo del gamepass daría 130 studs/s: cruza una sala de ~35 studs en un cuarto de segundo, el personaje se pasa de largo los objetos y la cámara no acompaña. Con 80 (velocidad) y 24 (radio) el x2 se entrega íntegro durante casi toda la partida y solo se recorta en el endgame. **El evento entra el último en `ApplyPerkBonus` y con su propio tope, por la misma razón que el gamepass: sin evento el multiplicador es 1 y nadie nota que el sistema existe.**
- **La iluminación la cambia el cliente, no el servidor.** Es presentación pura, las escrituras del cliente sobre Lighting son locales, y así la transición se suaviza por jugador sin gastar una replicación. Los valores authored se capturan en `Init` y se restauran al acabar: el controlador **nunca inventa una iluminación por defecto propia**, mezcla contra la del editor con `SkyBlend`.
- **`PerkService` vigila el evento una sola vez, no una por jugador.** Un evento cambia el perk de todos a la vez: dos conexiones para el servidor entero en lugar de dos por cabeza.
- **Object Rain solo acorta lo que se encola a partir de ese momento.** Reordenar la cola al arrancar el evento costaría recorrer todas las sesiones del servidor para adelantar como mucho dos segundos, y la cola se vacía sola en ese mismo rato.
- **Object Rain se midió mal la primera vez.** La sonda emparejaba la última recogida con la siguiente reposición, y en ráfaga eso da números sin sentido (0,22 s sobre una base de 2 s). Solo vale la medida cuando hay **una sola** recogida pendiente. **Aplicable a cualquier medida de latencia sobre una cola: si puede haber dos en vuelo, la media miente.**
- Pruebas en Play, todas de punta a punta: Stickiness en la Rest Zone (1 → 2 con Sticky Storm → 3 con Super Sticky → 1 al parar); Wins en el pedestal de ToyRoom (1 → 2 con Golden Goo → 1); `WalkSpeed` del Humanoid 17,25 → 34,5 y radio 5 → 10, revertidos al acabar; respawn 2,02 s → 1,02 s con Object Rain; sorteo de 12 tiradas sin repetir dentro de la ventana anti-repetición y con los 6 eventos apareciendo; caducidad natural por temporizador limpiando atributos, perks y cartel; aviso `EVENT ENDED` durante 4 s; iluminación devuelta al valor authored. Id inválido rechazado con aviso. Teardown sin restos.
- **Sin verificar:** el arranque automático real (primer evento a los 2-5 min, cooldown de 10-15 min) no se esperó en Studio; se probó su sorteo y su cadena de fin, que es todo lo que ejecuta salvo la espera. Tampoco hay sonido de evento: no existe plantilla authored para él y crearla por código rompería la regla 5.

## Contrato reusable — eventos de mundo

### Componentes

- `GameConfig.WorldEvents`: catálogo y todos los tiempos, topes y valores de presentación. Añadir un evento es añadir una fila.
- `Shared.WorldEvents`: lectura pura del estado (id activo, tiempo restante, multiplicador por `Kind`). No escribe nada; servidor y cliente pasan los dos por aquí, así que ven siempre lo mismo.
- `WorldEventService`: dueño único del reloj y del estado publicado. No aplica modificadores.
- `WorldEventController`: cartel del HUD e iluminación. No concede nada.

### Contrato del DataModel

```text
ReplicatedStorage/Shared/WorldEventState   -- Configuration authored
  atributos: EventId, EndsAt, StartedAt, Sequence, AdminRequest
StarterGui/StickyHUD/WorldEventBanner      -- Frame authored
  Title (TextLabel), Timer (TextLabel), Stroke (UIStroke)
```

Si falta cualquiera de las dos, el sistema avisa y se queda apagado; no las construye por código.

### Para portarlo

Copiar los cuatro módulos, crear las dos instancias authored, reemplazar `GameConfig.WorldEvents` y llamar a `WorldEvents.GetMultiplier(kind)` en cada fórmula que deba reaccionar. Los `Kind` (`Stickiness`, `Wins`, `Speed`, `Radius`, `Spawn`) son convención de este juego: en otro se cambian sin tocar el servicio ni el controlador.

### Disparo manual

Escribir en el atributo `AdminRequest` de `WorldEventState`, **desde el servidor**:

```text
StickyStorm          arranca ese evento con la duración del catálogo
StickyStorm|120      arranca ese evento durante 120 s
random               sortea uno
stop                 corta el activo y devuelve el ciclo a su cooldown
```

Existe además porque `execute_luau` del MCP tiene su propia caché de `require` y no puede llamar al servicio que está corriendo; los atributos sí se escriben desde fuera.

### 2026-08-11 — El HUD compacto tras la UI de monetización

- **Añadir una columna a un lado cambia el presupuesto de todo el resto, y nada avisa.** `GamePassPanel` y `BoostPanel` entraron con sus propios `Compact*` bien puestos, pero el `StatsPanel` seguía con el ancho de cuando el lado derecho estaba libre y se metía 0.079 dentro de ellos. La variante compacta reparte una pantalla pequeña entre pocos elementos: cada vez que entre uno nuevo hay que volver a medir el hueco central, no solo colocar el nuevo.
- **El centro del hueco no es el centro de la pantalla.** Con la izquierda ocupando hasta 0.254 y la derecha desde 0.686, el centro real está en 0.470. Centrar en 0.5 deja el panel descuadrado y pegado a la columna de monetización.
- **Estrechar una caja con `TextScaled` no encoge la letra.** El tamaño de fuente lo manda el **alto** de la caja; el ancho solo decide si el texto cabe o se parte. Bajar el `StatsPanel` de 0.50 a 0.40 de ancho dejó el mínimo en los mismos 13 px, con `TextFits = true` en todas. Útil saberlo: cuando falta sitio horizontal, estrechar sale casi gratis mientras el texto siga cabiendo.
- **Comprobar solapes hay que hacerlo con todo visible a la vez.** `PickupFeedback` y `ActiveBoostChip` se pisaban desde que existe el chip, también en escritorio, y no se había visto porque los dos están ocultos por defecto y nunca coincidían en una captura. El caso que lo dispara es el más normal del juego: recoger algo con un boost activo. La sonda ahora fuerza `Visible = true` en los nueve elementos antes de medir.
- **La columna derecha cae sobre el botón de salto y no cabe arreglarlo moviendo números.** Para librar la zona en 640×320 la columna tendría que acabar en y≈0.53 y dos paneles de 0.36 necesitan 0.72. Es una decisión de diseño pendiente: menos botones a la vista en móvil, paneles más bajos, o cambiar de sitio la columna.
- **Sigue sin probarse en Play.** El intento anterior de `start_stop_play` por MCP dejó el place cerrado (`Place is not open`, `name: null` en `list_roblox_studios`). Los cambios sobrevivieron, pero no conviene repetirlo sin avisar. Queda pendiente en Play: que suene la pista única, `MusicController.GetStats().SingleTrack`, y leer `PlayerGui.TouchGui` para tener las zonas táctiles reales en vez de estimadas.

### 2026-08-11 — Lo que no detecta comparar rectángulos de frame

- **Un `UIListLayout` con más hijos de los que caben los dibuja fuera del padre, y el `AbsoluteSize` del padre no cambia.** `CounterStack` se dimensionó para dos contadores; al entrar un tercero los hijos pedían 1.190 del frame y el sobrante se pintaba por debajo, encima del botón de Rebirth. Mis comprobaciones de solapes daban "sin solapes" porque comparaban los rectángulos de los frames. La sonda ahora mide la **unión del frame con la de todos sus descendientes visibles**. Cualquier contenedor con layout necesita esa comprobación, no la del frame.
- **Un contenedor con layout tiene un invariante que hay que escribir: los pesos de los hijos más los huecos deben sumar 1.** Si no está anotado, el siguiente que añada un elemento no tiene forma de saber que rompe algo, porque no falla nada: solo se sale por abajo. Queda anotado junto a los pesos.
- **Un `UIListLayout.Padding` mixto (escala + offset) es una trampa en móvil.** El de `CounterStack` era `0.06 + 4px`: en escritorio esos 4 px no se notan y en un teléfono los 8 px de los dos huecos eran justo lo que desbordaba la pila. Para UI que escala, el padding en escala pura.
- **"Se solapa" del usuario no siempre es solape.** Lo del panel central eran huecos de 2-3 px entre filas: técnicamente correcto, visualmente pegado. Medir el hueco mínimo entre filas es tan útil como medir el solape, y sale de la misma pasada.
- **Alguien movió etiquetas del `StatsPanel` a mano en Studio.** `WrapLabel` estaba en `y = 0.287` en vez de `0.355`, solapando 18 px con la `Stickiness` en escritorio, y los botones del HUD tienen posiciones con decimales sueltos (`0.244808614`). Al retomar un lugar que han tocado otros conviene volver a medir el layout base, no solo el que uno cambió.
- **Cuidado al probar con un viewport inventado.** Probé el HUD a 1045×500 creyendo que era el móvil del usuario y ese tamaño **no entra en compacto** (1045 > 820 y 500 > 430): medí el layout de escritorio y saqué conclusiones equivocadas. Una captura de móvil está en píxeles físicos y Roblox razona en puntos, así que no se puede deducir el viewport de una imagen. Por eso el tamaño del panel se topa ahora con un valor absoluto (`CompactMaxSize`), que no depende de acertar con la resolución.

### 2026-08-20 — Moving Platform Challenge

- **Un sistema que no concede nada no necesita autoridad de servidor sobre su geometría.** El
  challenge no da Wins, ni Stickiness, ni abre blockers, así que la posición de las plataformas no
  arbitra ningún premio. Eso permite calcularla en cada cliente como función pura de
  `Workspace:GetServerTimeNow()`: todos ven lo mismo, se mueve a la tasa de fotogramas de cada uno
  y no se replica un solo CFrame. Lo que sí es autoridad —devolver al inicio y dar el tramo por
  cruzado— vive entero en el servidor, sobre volúmenes fijos que el servidor sí conoce. La
  pregunta útil antes de simular algo en el servidor es *qué decisión depende de esta posición*.
- **`ProgressionService.ResetRun` no borra la economía: solo rebobina la zona.** Escribe
  `CurrentZoneId` con la zona de inicio del mundo y resincroniza atributos; Stickiness, Level,
  Wins y Rebirths quedan como estaban. Di por hecho lo contrario por el nombre y construí un
  teletransporte propio para el fallo del challenge, cuando el camino correcto era el que ya
  existía, `FinishService.ReturnToStart`. Antes de duplicar un flujo "porque el que hay hace de
  más", hay que leer qué hace de verdad: aquí costó una versión que dejaba al jugador en el lobby
  con el montón pegado y el mapa abierto hasta donde se cayó.
- **Un baseplate viejo puede anular un foso entero sin dar la cara.** El `Baseplate` por defecto,
  2048×2048 a Y 0, tapaba el hueco recién abierto en el suelo de Bedroom: caerse eran 1 stud y el
  `FailVolume` a Y -20 no se tocaba nunca. Antes de dar por hecho que un agujero es un agujero,
  `GetPartBoundsInBox` sobre el volumen del foso lo dice en una línea.
- **El `require` del command bar del MCP cachea el módulo y esconde las correcciones.** Un test
  seguía midiendo el doble de velocidad después de arreglar la fórmula porque devolvía la versión
  vieja. La salida es clonar el módulo con otro nombre y requerir la copia: caché nueva, código
  nuevo. Sin ese truco, un test verde o rojo no dice nada tras editar.
- **El bug lo cazó medir studs por segundo, no leer la fórmula.** El ping-pong recorre `4 × Travel`
  por ciclo y el loop `2 × Travel`; con un único denominador el ping-pong iba al doble de la
  velocidad pedida y la fórmula parecía correcta a simple vista. Un test que compara la magnitud
  con su unidad declarada —"si pido 10 studs/s, ¿se mueve a 10?"— encuentra lo que la inspección
  no ve.
- **Con `StreamingEnabled`, el tag de un hijo puede llegar antes que el del padre.** La primera
  versión del controlador guardaba el `Enabled` del challenge en un mapa aparte y consultaba ese
  mapa al mover cada plataforma: una plataforma que se registrase antes que su challenge se habría
  quedado congelada en mitad del foso hasta que alguien tocara un atributo. Cada entrada guarda
  ahora su propia copia del estado, leída al registrarse.
- **Un freno de rebote armado antes de validar se come el evento bueno.** En el cruce, marcar el
  debounce antes de comprobar el sentido de entrada hacía que un roce descartado tapara el cruce
  legítimo del instante siguiente. El freno va después de la validación, siempre.
- **Comprobar que un tramo de habilidad es *cruzable* se puede hacer sin jugarlo.** Simulando las
  posiciones de los carriles a lo largo de dos minutos salen el porcentaje de tiempo en que dos
  plataformas consecutivas están al alcance de un salto y la espera máxima entre ventanas (75 % y
  1.7 s aquí). Es la diferencia entre "las plataformas se mueven" y "el tramo se puede pasar".
- **Una parte anclada movida por `CFrame` no arrastra al personaje que la pisa.** Medido: la
  plataforma recorrió 14,76 studs y el jugador 0,00. Roblox no calcula velocidad para lo anclado,
  así que no hay rozamiento que empuje a nadie, y el `FloorMaterial` sigue diciendo que está
  apoyado mientras la plataforma se le va de debajo. La solución que encaja con mover las
  plataformas en cliente es transportar explícitamente al personaje local: rayo hacia abajo desde
  el root para saber qué pisa, y el mismo delta del fotograma sumado al root. Desfase medido
  después: 0.00, también al invertir el sentido.
- **`Touched` no dispara al teletransportar.** Dos pruebas de cruce dieron falso negativo porque
  movían al personaje con `PivotTo` en vez de andando; el volumen estaba bien y el jugador dentro
  (`IsInsideVolume` = true), pero nunca hubo evento. Para probar cualquier volumen hay que entrar
  con `Humanoid:MoveTo` o cayendo. Una sonda que cuenta los `Touched` reales del volumen distingue
  en una sola pasada "el volumen no dispara" de "el servicio lo rechaza".
- **`CanTouch = false` deja una placa perfectamente registrada y completamente muerta.** Tras mover
  los assets del lobby de World 1, 23 parts de `Zones.Lobby` quedaron con `CanTouch` y `CanQuery`
  en `false`: los WrapPads, `WorldPortal.Pad`, `WorldPortal.Arch`, las 7 `RestPad_RestZone*` y los
  7 `NextZoneSign`. El tag `WrapPad` y el atributo `WrapId` seguían intactos, así que
  `WrapPadService` registraba las placas sin un solo warn y la consola salía limpia — pero
  `Touched` no dispara nunca con `CanTouch = false`, así que pisarlas no hacía nada. Diagnóstico en
  una pasada: comparar propiedad por propiedad el lobby sospechoso contra `W2_Lobby`/`W3_Lobby`,
  que son el mismo grupo clonado y no se habían tocado. Cuando existe un gemelo sano en el
  DataModel, el diff contra el gemelo encuentra el destrozo de una edición múltiple accidental
  mucho antes que releer el servicio.
- **Abrir un hueco en el suelo de una sala le quita sitios de colocación, y el aviso llega tarde.**
  El foso de Bedroom dejó la sala en 26 sitios para 32 objetos. `ItemPlacementService` lo dice solo,
  pero solo cuando alguien entra en esa sala con esa zona activa: en una prueba en la que el
  jugador pasa por encima sin tenerla activa, no se genera nada y la consola sale limpia sin que
  eso signifique nada. Para comprobar colocación hay que hacer la vuelta de verdad —absorber el
  blocker que abre la sala— y contar los objetos.
